/* -*- c++ -*- */
/* 
 * Copyright 2015 <+YOU OR YOUR COMPANY+>.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "yunsdr_sink_impl.h"

typedef struct sockaddr SA;

#define TX_SAMPLES_NUM  (1024*8)
#define MIN_NUM_SAMPLES 1
#define MAX_NUM_SAMPLES 8196


namespace gr {
    namespace yunsdr {

        yunsdr_sink::sptr
            yunsdr_sink::make(const std::string &ipaddr, uint32_t port,
                    uint64_t tx_freq, uint32_t tx_vga, uint32_t sample_rate, uint32_t bw,
                    uint32_t ref_sel, uint32_t vco_sel, uint32_t ftdd_sel,
                    uint32_t auxdac1, uint32_t trx_sw, uint32_t channel)
            {
                return gnuradio::get_initial_sptr
                    (new yunsdr_sink_impl(ipaddr, port, tx_freq, tx_vga, sample_rate, bw,
                                          ref_sel, vco_sel, ftdd_sel, auxdac1, trx_sw, channel));
            }

        /*
         * The private constructor
         */
        yunsdr_sink_impl::yunsdr_sink_impl(const std::string &ipaddr,
                uint32_t port,uint64_t tx_freq, uint32_t tx_vga, uint32_t sample_rate, uint32_t bw,
                uint32_t ref_sel, uint32_t vco_sel, uint32_t ftdd_sel, 
                uint32_t auxdac1, uint32_t trx_sw, uint32_t channel)
            : gr::sync_block("yunsdr_sink",
                    gr::io_signature::make(1, 2, sizeof(gr_complex)),
                    gr::io_signature::make(0, 0, sizeof(gr_complex)))
        {

            _buf_used = 0;
            d_ipaddr = ipaddr;
            d_port = port;
            d_tx_vga = tx_vga;
            d_tx_freq = tx_freq;
            d_sample_rate = sample_rate;
            if(this->connect_server() < 0)
                throw std::runtime_error("zingsdr:connect server error!\n");
            this->channel_sel(channel);
            this->set_freq(d_tx_freq);
            this->set_gain(d_tx_vga*1000);
            this->set_sample_rate(d_sample_rate);
            this->set_bandwith(bw);
            this->set_ref_select(ref_sel);
            this->set_vco_cal_select(vco_sel);
            this->set_fdd_tdd_select(ftdd_sel);
            this->set_trx_sw_select(trx_sw);
            if(auxdac1 == 1)
                this->set_auxdac1(auxdac1);
            this->handshake();

            p = (struct ring_buffer *)malloc(sizeof(struct ring_buffer));
            p->front = p->rear = 0;
            int i = 0;
            for(i = 0; i< RING_BUFFER_MAXSIZE; i++)
                p->data[i] = (unsigned char *)malloc(TX_SAMPLES_NUM);

            _running = true;
            if(pthread_create(&thread_send, NULL, creat_send_thread, this) < 0)
                throw std::runtime_error("zingsdr:creat recv thread error!\n");
        }


        /*
         * Our virtual destructor.
         */
        yunsdr_sink_impl::~yunsdr_sink_impl()
        {
            int i = 0;

            _running = false;
            pthread_join(thread_send, NULL);

            for(i = 0; i< RING_BUFFER_MAXSIZE; i++)
                free(p->data[i]);
            free(p);

            //pthread_cancel(thread_send);

            if(this->disconnect_server() < 0)
                throw std::runtime_error("zingsdr:disconnect server error!\n");
        }

        int
            yunsdr_sink_impl::work(int noutput_items,
                    gr_vector_const_void_star &input_items,
                    gr_vector_void_star &output_items)
            {
                unsigned int nchan = input_items.size();
                const gr_complex **in = (const gr_complex **)&input_items[0];
                //const gr_complex *in = (const gr_complex *) input_items[0];
                gr_complex *out = (gr_complex *) output_items[0];

                // Do <+signal processing+>

                const float scaling = 2000.0f;
                //const float scaling = 1.0f;
                int i;
                char *buf = _buf + _buf_used;
                unsigned int prev_buf_used = _buf_used;

                unsigned int remaining = (TX_SAMPLES_NUM-_buf_used)/4; //complex

                unsigned int count = std::min((unsigned int)noutput_items,remaining);

                _buf_used += count * 4;
                if(nchan == 1){
                    for(i = 0; i < count*4; i+=4)
                    {
                        (*(short *)(buf + i)) = (short)(scaling * in[0][i/4].real());
                        (*(short *)(buf + i + 2)) = (short)(scaling * in[0][i/4].imag());
                    }
                } else if(nchan == 2) {
                    for(i = 0; i < count*4; i+=8)
                    {
                        (*(short *)(buf + i)) = (short)(scaling * in[0][i/8].real());
                        (*(short *)(buf + i + 2)) = (short)(scaling * in[0][i/8].imag());
                        (*(short *)(buf + i + 4)) = (short)(scaling * in[0][i/8].real());
                        (*(short *)(buf + i + 6)) = (short)(scaling * in[0][i/8].imag());
                    }
                }

                int items_consumed = count;

                if((unsigned int)noutput_items >= remaining) {
                    {
                        if((p->rear + 1) % RING_BUFFER_MAXSIZE == p->front) {
                            _buf_used = prev_buf_used;
                            items_consumed = 0;
                            //std::cerr << "O" << std::flush;
                        }
                        else {
                            memcpy(p->data[p->rear], _buf, TX_SAMPLES_NUM);
                            p->rear = (p->rear + 1) % RING_BUFFER_MAXSIZE;
                            _buf_used = 0;
                        }
                    }
                }

                // Tell runtime system how many input items we consumed on
                // each input stream.
                consume_each(items_consumed);

                // Tell runtime system how many output items we produced.
                return 0;
            }

        void yunsdr_sink_impl::channel_sel(uint32_t id)
        {
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0200000|(id&0x03);
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));

            //return 0;
        }

        void yunsdr_sink_impl::set_freq(uint64_t freq)
        {
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(3<<8)|(freq>>32);
            cmd_buf[1] = freq&0x00FFFFFFFFUL; /*set tx freq*/
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));

            //return 0;
        }
        void yunsdr_sink_impl::set_gain(uint32_t gain)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000 | (9<<8); //set tx vga
            cmd_buf[1] = gain;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));

            cmd_buf[0] = 0xF0220000 | (11<<8); //set tx vga
            cmd_buf[1] = gain;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }

        void yunsdr_sink_impl::set_sample_rate(uint32_t sample_rate)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(5<<8);
            cmd_buf[1] = sample_rate;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }
        void yunsdr_sink_impl::set_bandwith(uint32_t bw)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(7<<8);
            cmd_buf[1] = bw;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }

        void yunsdr_sink_impl::set_ref_select(uint32_t sel)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(40<<8);
            cmd_buf[1] = sel;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }
        void yunsdr_sink_impl::set_vco_cal_select(uint32_t sel)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(41<<8);
            cmd_buf[1] = sel;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }
        void yunsdr_sink_impl::set_fdd_tdd_select(uint32_t sel)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(42<<8);
            cmd_buf[1] = sel;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }
        void yunsdr_sink_impl::set_trx_sw_select(uint32_t sel)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(43<<8);
            cmd_buf[1] = sel;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }
        void yunsdr_sink_impl::set_auxdac1(uint32_t value)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(44<<8);
            cmd_buf[1] = value;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }
        int yunsdr_sink_impl::handshake()
        {
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0160001;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));

            sleep(1);

            return 1;
        }
        int yunsdr_sink_impl::send_sample()
        {
            unsigned int cmd_buf[2]={0,0};
            int len = 0, i = 0, nbyte = 0;
            //unsigned char msg[TX_SAMPLES_NUM];

            while(_running) {
                if(p->front == p->rear) {
                    //std::cerr << "U" << std::flush;
                    sleep(0);
                }
                else {
                    //#define YUNSDR_64BIT
#ifdef YUNSDR_64BIT
                    char *tmp_dst = _buf_64bit;
                    char *tmp_src = (p->data[p->front]);
                    for(i = 0; i < TX_SAMPLES_NUM/4; i++){
                        *tmp_dst = *tmp_src;
                        *(tmp_dst + 1) = *(tmp_src + 1);
                        *(tmp_dst + 2) = *(tmp_src + 2);
                        *(tmp_dst + 3) = *(tmp_src + 3);
                        tmp_dst += 8;
                        tmp_src += 4;
                    }
                    if(send(sock_sink, _buf_64bit, TX_SAMPLES_NUM, 0) < 0)
                        break;
                    if(send(sock_sink, _buf_64bit+TX_SAMPLES_NUM, TX_SAMPLES_NUM, 0) < 0)
                        break;
#else
#if 0
                    FILE *fp;
                    fp = fopen("/home/jacky/Work/tone.bin", "a");
                    fwrite(p->data[p->front], TX_SAMPLES_NUM, 1, fp);
                    fclose(fp);
#endif
                    pthread_testcancel();
                    //if(send(sock_sink, _buf_64bit, TX_SAMPLES_NUM, 0) < 0)
                    if(send(sock_sink, p->data[p->front], TX_SAMPLES_NUM, 0) < 0)
                        break;
                    pthread_testcancel();
#endif
                    p->front = (p->front + 1) % RING_BUFFER_MAXSIZE;
                }
            }
        }
        void *yunsdr_sink_impl::creat_send_thread(void *param)
        {
            //pthread_detach(pthread_self());
            yunsdr_sink_impl *pThis = (yunsdr_sink_impl *)param;
            pThis->send_sample();
            return NULL;
        }

        int yunsdr_sink_impl::connect_server()
        {
            if((sock_cmd = socket(PF_INET, SOCK_DGRAM, 0)) < 0)
            {
                perror("fail to socket!");
                return -1;
            }

            bzero(&cmd_addr, sizeof(cmd_addr));
            cmd_addr.sin_family = PF_INET;
            cmd_addr.sin_port = htons(5006);
            cmd_addr.sin_addr.s_addr = inet_addr(d_ipaddr.c_str());

            if((sock_sink = socket(PF_INET, SOCK_STREAM, 0)) < 0)
            {
                perror("fail to socket!");
                return -1;
            }

            bzero(&sink_addr, sizeof(sink_addr));
            sink_addr.sin_family = PF_INET;
            sink_addr.sin_port = htons(5005);
            sink_addr.sin_addr.s_addr = inet_addr(d_ipaddr.c_str());

            if(connect(sock_sink, (struct sockaddr *)&sink_addr, sizeof(struct sockaddr)) < 0){
                perror("connect");
                printf("connect (%d)\n",errno);
            } else {
                printf("connect sucessful\n");
            }

            return 1;
        }
        int yunsdr_sink_impl::disconnect_server()
        {
            close(sock_sink);
            return 0;
        }
    } /* namespace yunsdr */
} /* namespace gr */

