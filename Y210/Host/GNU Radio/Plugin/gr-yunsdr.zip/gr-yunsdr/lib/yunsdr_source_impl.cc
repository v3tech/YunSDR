/* -*- c++ -*- */
/* 
 * Copyright 2015 <+YOU OR YOUR COMPANY+>.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "yunsdr_source_impl.h"
#include <boost/thread/thread.hpp>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

typedef struct sockaddr SA;

namespace gr {
  namespace yunsdr {

    yunsdr_source::sptr
    yunsdr_source::make(const std::string &ipaddr, uint32_t port,
            uint64_t rx_freq, uint32_t rx_vga,uint32_t sample_rate,uint32_t bw, 
            uint32_t ref_sel, uint32_t vco_sel, uint32_t ftdd_sel,
            uint32_t auxdac1, uint32_t trx_sw, uint32_t channel)
    {
      return gnuradio::get_initial_sptr
        (new yunsdr_source_impl(ipaddr, port, rx_freq, rx_vga, sample_rate, bw,
                                ref_sel, vco_sel, ftdd_sel, auxdac1, trx_sw, channel));
    }

    /*
     * The private constructor
     */
    yunsdr_source_impl::yunsdr_source_impl(const std::string &ipaddr, 
            uint32_t port,uint64_t rx_freq, uint32_t rx_vga,uint32_t sample_rate, uint32_t bw,
            uint32_t ref_sel, uint32_t vco_sel, uint32_t ftdd_sel, 
            uint32_t auxdac1, uint32_t trx_sw, uint32_t channel)
      : gr::sync_block("yunsdr_source",
              gr::io_signature::make(0, 0, sizeof(gr_complex)),
              gr::io_signature::make(1, 1, sizeof(gr_complex)))
    {

            d_ipaddr = ipaddr;
            d_port = port;
            d_rx_vga = rx_vga;
            d_rx_freq = rx_freq;
            d_sample_rate = sample_rate;
            sock_len = sizeof(source_addr);
            if(this->connect_server() < 0)
                throw std::runtime_error("zingsdr:connect server error!\n");
            this->channel_sel(channel);
            this->set_freq(d_rx_freq);
            this->set_gain(d_rx_vga);
            this->set_sample_rate(d_sample_rate);
            this->set_bandwidth(bw);
            this->set_ref_select(ref_sel);
            this->set_vco_cal_select(vco_sel);
            this->set_fdd_tdd_select(ftdd_sel);
            this->set_trx_sw_select(trx_sw);
            if(auxdac1 == 1)
                this->set_auxdac1(auxdac1);
            this->handshake();

            _fifo = new boost::circular_buffer<gr_complex>(RX_SAMPLES_NUM*4096);
            if (!_fifo) {
                throw std::runtime_error( std::string(__FUNCTION__) + " " +
                        "Failed to allocate a sample FIFO!" );
            }
            this->start();

    }

    /*
     * Our virtual destructor.
     */
    yunsdr_source_impl::~yunsdr_source_impl()
    {
        if(this->disconnect_server() < 0)
                throw std::runtime_error("zingsdr:disconnect server error!\n");

            this->stop();
            int i = 0;
            close(sock_source);
            if (_fifo)
            {
                delete _fifo;
                _fifo = NULL;
            }

    }

    int
    yunsdr_source_impl::work(int noutput_items,
			  gr_vector_const_void_star &input_items,
			  gr_vector_void_star &output_items)
    {
        //const gr_complex *in = (const <+ITYPE+> *) input_items[0];
        gr_complex *out = (gr_complex *) output_items[0];

        // Do <+signal processing+>

                boost::unique_lock<boost::mutex> lock(_fifo_lock);

                /* Wait until we have the requested number of samples */
                int n_samples_avail = _fifo->size();

                while (n_samples_avail < noutput_items) {
                    _samp_avail.wait(lock);
                    n_samples_avail = _fifo->size();
                }

                for(int i = 0; i < noutput_items; ++i) {
                    out[i] = _fifo->at(0);
                    _fifo->pop_front();
                }

                //std::cerr << "-" << std::flush;
        // Tell runtime system how many output items we produced.
        return noutput_items;
    }

        void yunsdr_source_impl::channel_sel(uint32_t id)
        {
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0210000|(id&0x03);
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }

        void yunsdr_source_impl::set_freq(uint64_t freq)
        {
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(15<<8)|(freq>>32);
            cmd_buf[1] = freq&0x00FFFFFFFFUL; /*set rx freq*/
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }
        void yunsdr_source_impl::set_gain(uint32_t gain)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(21<<8);
            cmd_buf[1] = 0x0;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            cmd_buf[0] = 0xF0220000|(23<<8);
            cmd_buf[1] = 0x0;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));

            cmd_buf[0] = 0xF0220000|(25<<8);
            cmd_buf[1] = gain; //set rx vga
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            cmd_buf[0] = 0xF0220000|(27<<8);
            cmd_buf[1] = gain; //set rx vga
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }
        void yunsdr_source_impl::set_sample_rate(uint32_t sample_rate)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(17<<8);
            cmd_buf[1] = sample_rate;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }
        void yunsdr_source_impl::set_bandwidth(uint32_t bw)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(19<<8);
            cmd_buf[1] = bw;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }

        void yunsdr_source_impl::set_ref_select(uint32_t sel)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(40<<8);
            cmd_buf[1] = sel;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }
        void yunsdr_source_impl::set_vco_cal_select(uint32_t sel)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(41<<8);
            cmd_buf[1] = sel;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }
        void yunsdr_source_impl::set_fdd_tdd_select(uint32_t sel)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(42<<8);
            cmd_buf[1] = sel;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }
        void yunsdr_source_impl::set_trx_sw_select(uint32_t sel)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(43<<8);
            cmd_buf[1] = sel;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }
        void yunsdr_source_impl::set_auxdac1(uint32_t value)
        { 
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0220000|(44<<8);
            cmd_buf[1] = value;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            //return 0;
        }
        int yunsdr_source_impl::handshake()
        {
            uint32_t cmd_buf[2]={0,0};
            cmd_buf[0] = 0xF0160101;
            sendto(sock_cmd, cmd_buf, sizeof(cmd_buf), 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
            
            sleep(1);

            return 1;
        }

        bool yunsdr_source_impl::start()
        {
            _running = true;
            _thread = gr::thread::thread(_recv_samples, this);

            return true;
        }
        bool yunsdr_source_impl::stop()
        {
            _running = false;
            _thread.join();

            return true;
        }
        void yunsdr_source_impl::_recv_samples(yunsdr_source_impl *obj)
        {
            obj->recv_samples();
        }
        void yunsdr_source_impl::recv_samples()
        {
            while(_running) {
#ifdef YUNSDR_64BIT
                if(recv(sock_source, _buf_64bit, RX_SAMPLES_NUM, MSG_WAITALL) == 0)
                    break;
                int j;
                int *tmp_dst = (int *)_buf;
                int *tmp_src = (int *)_buf_64bit;
                for(j = 0; j < RX_SAMPLES_NUM/4; j++){
                        *tmp_dst = *tmp_src;
                        tmp_dst += 1;
                        tmp_src += 2;
                }
                size_t num_samples = RX_SAMPLES_NUM/4/2;
#else
                if(recv(sock_source, _buf, RX_SAMPLES_NUM, MSG_WAITALL) == 0)
                    break;
                size_t num_samples = RX_SAMPLES_NUM/4;
#endif
                size_t i, n_avail, to_copy;
                short *sample = (short *)_buf;
                _fifo_lock.lock();

                n_avail = _fifo->capacity() - _fifo->size();
                to_copy = (n_avail < num_samples ? n_avail : num_samples);

                for (i = 0; i < to_copy; i++ )
                {
                    /* Push sample to the fifo */
                    _fifo->push_back( gr_complex( *sample, *(sample+1) ) );

                    /* offset to the next I+Q sample */
                    sample += 2;
                }

                _fifo_lock.unlock();

                /* We have made some new samples available to the consumer in work() */
                if (to_copy) {
                    //std::cerr << "+" << std::flush;
                    _samp_avail.notify_one();
                }

                /* Indicate overrun, if neccesary */
                if (to_copy < num_samples)
                    ;//std::cerr << "O" << std::flush;
            }
        }

        int yunsdr_source_impl::connect_server()
        {

            if((sock_cmd = socket(PF_INET, SOCK_DGRAM, 0)) < 0)
            {
                perror("fail to socket!");
                return -1;
            }

            bzero(&cmd_addr, sizeof(cmd_addr));
            cmd_addr.sin_family = PF_INET;
            cmd_addr.sin_port = htons(5006);
            cmd_addr.sin_addr.s_addr = inet_addr(d_ipaddr.c_str());

            if((sock_source = socket(PF_INET, SOCK_STREAM, 0)) < 0)
            {
                perror("fail to socket!");
                return -1;
            }

            sock_len = sizeof(struct sockaddr_in);
            memset(&source_addr, 0, sock_len);
            source_addr.sin_family = AF_INET;
            source_addr.sin_port = htons(5004);
            if (inet_pton(AF_INET, d_ipaddr.c_str(), &source_addr.sin_addr) <= 0) {
                printf("Wrong dest IP address!\n");
            }

            if(connect(sock_source, (struct sockaddr *)&source_addr, sizeof(struct sockaddr)) < 0){
                perror("connect");
                printf("connect (%d)\n",errno);
            } else {
                printf("connect sucessful\n");
            }

            return 1;
        }
        int yunsdr_source_impl::disconnect_server()
        {
            return 0;
        }
  } /* namespace yunsdr */
} /* namespace gr */

