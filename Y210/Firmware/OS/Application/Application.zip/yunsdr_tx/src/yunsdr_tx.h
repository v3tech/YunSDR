/*
 * yunsdr_rx.h
 *
 *  Created on: 2015-9-2
 *      Author: Eric
 */

#ifndef YUNSDR_RX_H_
#define YUNSDR_RX_H_

struct dma_dev m2s_dev;
unsigned int dac_mode = E_GNURADIO_MODE;
struct global_param dac_param;

int client_connect;
pthread_t thread_dac, thread_recv, thread_demo;
char buffer[16384];
uint8_t *buf;
struct ring_buf *cb_dac;
unsigned int first_run = 0;

/**
 * Function declaration
 */

void *thread_dac_func(void *arg);
void *thread_dac_demo(void *arg);
void *thread_recvfrom_func(void *arg);
int recv_msg(long int msgtype, unsigned int *mode);
int send_msg(long int msg_type, unsigned int param);
static void sig_pipe(int signo);
static void sig_usr1(int signo);

#endif /* YUNSDR_RX_H_ */
