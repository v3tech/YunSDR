/**
 * $Id: yunsdr_tx_main.c 2015-1
 *
 * @brief YunSDR TX main Module.
 *
 * @Author Eric <gaocc@v3best.com>
 *
 * (c) V3best  http://www.zingsoc.com
 *
 * This part of code is written in C programming language.
 * Please visit http://en.wikipedia.org/wiki/C_(programming_language)
 * for more details on the language used herein.
 */
#define _GNU_SOURCE 1

#include <signal.h>
#include <stdint.h>
#include <arpa/inet.h>
#include <yunsdr_hw.h>
#include <yunsdr_sw.h>
#include <linux/ioctl.h>
#include <linux/tcp.h>
#include <sys/msg.h>
#include <yunsdr.h>
#include "yunsdr_tx.h"

int main (int argc, char *argv[])
{

	int ret, i, flag;
	struct timeval tv;
	int nRecvBufLen = 1*1024*1024;
	first_run = 1;

	dma_dbg(MSG_DEBUG,"TX:Build: %s  %s\n", __TIME__, __DATE__);

	if (signal(SIGPIPE, sig_pipe) == SIG_ERR) {
		dma_dbg(MSG_ERROR, "TX:can't catch SIGPIPE\n");
		exit(1);
	}
	if (signal(SIGUSR1, sig_usr1) == SIG_ERR) {
		dma_dbg(MSG_ERROR, "TX:can't catch SIGUSR1\n");
		exit(1);
	}

	m2s_dev.fd = -1;
	m2s_dev.membase = NULL;
	m2s_dev.mode = M_UNINIT;
	m2s_dev.regbase = NULL;
	m2s_dev.dir = MM2S_CHANNEL;

	if(init_m2s_channel(&m2s_dev) == R_ERROR) {
		dma_dbg(MSG_ERROR, "TX:can't init m2s channel\n");
		exit(1);
	}

	buf = (uint8_t *)malloc(MM2S_BUF_SIZE/2);
	if(buf == NULL) {
		dma_dbg(MSG_ERROR, "TX:can't malloc memory\n");
		return R_ERROR;
	}
	/**
	 * Simple ring buffer
	 */
#if 0
	uint8_t *cb_base = m2s_dev.membase + (20 * 1024 *1024);
#else
	uint8_t *cb_base = malloc(20 * 1024 *1024);
#endif
	cb_dac = (struct ring_buf *)malloc(sizeof(struct ring_buf));
	cb_dac->front = cb_dac->rear = 0;
	for(i = 0; i < MaxSize; i++)
		cb_dac->data[i] = cb_base + (i * BUFFER_MAX_SIZE);

	/************************dac tcp socket**********************/
	dac_param.sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(dac_param.sockfd == -1)
	{
		dma_dbg(MSG_ERROR,"TX:socket error:%s\n",strerror(errno));
		return -1;
	}
	/* Disable the Nagle (TCP No Delay) algorithm */
	flag = 1;
	ret = setsockopt(dac_param.sockfd, IPPROTO_TCP, TCP_NODELAY, (char *)&flag, sizeof(flag) );
	if (ret == -1) {
	  printf("Couldn't setsockopt(TCP_NODELAY)\n");
	}
	bzero(&dac_param.server_addr, sizeof(dac_param.server_addr));
	dac_param.server_addr.sin_family = AF_INET;
	dac_param.server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	dac_param.server_addr.sin_port = htons(5005);
	ret = bind(dac_param.sockfd, (struct sockaddr *)&(dac_param.server_addr), sizeof(dac_param.server_addr));
	if(ret == -1)
	{
		dma_dbg(MSG_ERROR,"TX:bind error:%s\n", strerror(errno));
		return -1;
	}

	ret = listen(dac_param.sockfd, 1);
	if(ret == -1)
	{
		dma_dbg(MSG_ERROR,"TX:listen error\n");
		return -1;
	}
	while(1)
	{
		dac_param.client_len = sizeof(struct sockaddr);
		dac_param.clifd =accept(dac_param.sockfd, (struct sockaddr *)&(dac_param.client_addr),
				&(dac_param.client_len));
		if(dac_param.clifd == -1)
		{
			dma_dbg(MSG_ERROR,"TX:accept error\n");
		}else{
			dma_dbg(MSG_DEBUG,"TX:client connect!\n");
		}
		client_connect = E_CLIENT_CONNECT;
		setsockopt(dac_param.clifd, SOL_SOCKET, SO_RCVBUF, (const char *)&nRecvBufLen, sizeof(int) );
		/************************************************************/
		if(recv_msg(1, &dac_mode) < 0){
			dma_dbg(MSG_ERROR,"TX:recv msg failed\n");
			close(dac_param.clifd);
			client_connect = E_CLIENT_DISCONNECT;
			dma_dbg(MSG_DEBUG,"TX:connect close!\n");
			continue;
		}
		if(dac_mode == E_GNURADIO_MODE){
			ret = pthread_create(&thread_dac, NULL, &thread_dac_func, &dac_mode);
			if (ret)
			{
				dma_dbg(MSG_ERROR, "TX:ERROR, return code from pthread_create() is %d\n", ret);
				return -1;
			}
			ret = pthread_create(&thread_recv, NULL, &thread_recvfrom_func, NULL);
			if (ret)
			{
				dma_dbg(MSG_ERROR, "TX:ERROR, return code from pthread_create() is %d\n", ret);
				return -1;
			}

			pthread_join(thread_dac,NULL);
			pthread_join(thread_recv,NULL);
			cb_dac->front = cb_dac->rear=0;
		}
		if(dac_mode == E_MATLAB_MODE){
			tv.tv_sec = 10;
			tv.tv_usec = 0;
#define  RECV_TIMEOUT
#ifdef  RECV_TIMEOUT
			setsockopt(dac_param.clifd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
#else
			setsockopt(dac_param.clifd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
#endif
			ret = pthread_create(&thread_dac, NULL, &thread_dac_func, &dac_mode);
			if (ret)
			{
				dma_dbg(MSG_ERROR, "TX:ERROR, return code from pthread_create() is %d\n", ret);
				return -1;
			}
			if(first_run){
				ret = pthread_create(&thread_demo, NULL, &thread_dac_demo, NULL);
				if (ret)
				{
					dma_dbg(MSG_ERROR, "TX:ERROR, return code from pthread_create() is %d\n", ret);
					return -1;
				}
				first_run = 0;
			}
			pthread_join(thread_dac,NULL);
			close(dac_param.clifd);
			client_connect = E_CLIENT_DISCONNECT;
			dma_dbg(MSG_DEBUG, "TX:connect close!\n");
		}
	}

	return 0;
}


/**
 * @brief  send data to axi dma thread.
 *
 * @param[in]  temp               user parameters
 * @retval                        NULL
 *
 */
void *thread_dac_func(void *arg)
{
	//pthread_detach(pthread_self());
	cpu_set_t mask ;
	CPU_ZERO(&mask);
	CPU_SET(2,&mask);
	int ret = 0;
	unsigned int mode = *((unsigned int *)arg);

	ret =pthread_setaffinity_np(pthread_self(),sizeof(mask),(const cpu_set_t*)&mask );
	if(ret < 0)
		dma_dbg(MSG_ERROR,"TX:DAC thread:pthread_setaffinity_np error... \n");

	if(mode == E_GNURADIO_MODE){
		dma_dbg(MSG_DEBUG,"TX:DAC thread: Normal mode is running!\n");
		while(client_connect){
			if(cb_dac->front==cb_dac->rear)
			{
				//dma_dbg(MSG_WARNING,"cb empty!\n");
				//pthread_mutex_unlock(&lock);
				sleep(0);
				continue;
			}
			else
			{
				write_samples(&m2s_dev, cb_dac->data[cb_dac->front], PACKET_SIZE*2*4, M_NORMAL);
				cb_dac->front=(cb_dac->front+1)%MaxSize;
			}
		}
		hw_reset(&m2s_dev);
	}
	if(mode == E_MATLAB_MODE){
		int nbyte = 0;
		unsigned int len = 0, sum = 0;
		if(recv_msg(3, &len) < 0){
			dma_dbg(MSG_ERROR,"TX:recv msg failed\n");
		}
		dma_dbg(MSG_DEBUG,"TX:PC expect transmit %d bytes!\n", len);
		do {
			nbyte = recv(dac_param.clifd, buf + sum, len - sum, 0);
			sum += nbyte;
			if(nbyte <= 0){
				dma_dbg(MSG_ERROR,"TX:recv msg failed\n");
				return NULL;
			}
		}while(len != sum);
		dma_dbg(MSG_DEBUG,"TX:recv %d bytes!\n", len);
		if(write_samples(&m2s_dev, buf, len, M_LOOPBACK) == R_ERROR) {
			dma_dbg(MSG_DEBUG,"TX:DAC: loopback mode start failed!\n");
		} else {
			dma_dbg(MSG_DEBUG,"TX:DAC: loopback mode is running!\n");
		}
	}
	return NULL;
}
void *thread_recvfrom_func(void *arg)
{
	int ret = 0;
	cpu_set_t mask ;
	CPU_ZERO(&mask);
	CPU_SET(1,&mask);

	ret =pthread_setaffinity_np(pthread_self(),sizeof(mask),(const cpu_set_t*)&mask );
	if(ret < 0)
		dma_dbg(MSG_ERROR,"TX:recv thread:pthread_setaffinity_np error... \n");


	while(1){
		//pthread_mutex_lock(&lock);
		if((cb_dac->rear+1)%MaxSize==cb_dac->front)
		{
			dma_dbg(MSG_WARNING,"TX:cb full!\n");
			//pthread_mutex_unlock(&lock);
			sleep(0);
			continue;
		}
		else
		{
			//ret = recv(dac_param.clifd, p->data[p->rear], PACKET_SIZE*8, MSG_WAITALL);
			ret = recv(dac_param.clifd, cb_dac->data[cb_dac->rear], PACKET_SIZE*8, MSG_WAITALL);
			if(ret == 0){
				close(dac_param.clifd);
				client_connect = E_CLIENT_DISCONNECT;
				dma_dbg(MSG_ERROR,"TX:connect close!\n");
				break;
			}else if(ret < 0){
				dma_dbg(MSG_ERROR,"TX:recv error!\n");
				continue;
			}
			//memcpy(cb_dac->data[cb_dac->rear], buffer, PACKET_SIZE*8);
			cb_dac->rear=(cb_dac->rear+1)%MaxSize;
		}
	}
	return NULL;
}

void *thread_dac_demo(void *arg)
{
	pthread_detach(pthread_self());
	unsigned int mark;

	while(1){
		if(recv_msg(5, &mark) < 0){
			dma_dbg(MSG_ERROR,"TX:recv msg failed\n");
		}
		if(dac_mode == E_MATLAB_MODE){
			if(mark==0xff){
				hw_reset(&m2s_dev);
			}
		}
	}
	return NULL;
}
/**
 * @brief  SIGPIPE handle to avoid program quit from wrong network connection
 *
 * @param[in]  signo              signal id
 * @retval                        void
 *
 */
static void sig_pipe(int signo)
{
	/*nothing to do*/
}
static void sig_usr1(int signo)
{
	deinit_m2s_channel(&m2s_dev);
	free(buf);
	free(cb_dac);
	exit(1);
}


int recv_msg(long int msgtype, unsigned int *param)
{
	int msgid = -1;
	struct msg_st data;
	//long int msgtype = 1;


	msgid = msgget((key_t)1234, 0666 | IPC_CREAT);
	if(msgid == -1)
	{
		dma_dbg(MSG_ERROR, "TX:msgget failed with error: %d\n", errno);
		return -1;
	}

	if(msgrcv(msgid, (void*)&data, sizeof(struct msg_st), msgtype, 0) == -1)
	{
		dma_dbg(MSG_ERROR, "TX:msgrcv failed with errno: %d\n", errno);
		return -1;
	}
	if(param != NULL)
		*param = data.param;

	return 0;
}
