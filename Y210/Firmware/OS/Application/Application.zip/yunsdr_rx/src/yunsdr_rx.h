/*
 * yunsdr_rx.h
 *
 *  Created on: 2015-8-28
 *      Author: Eric
 */

#ifndef YUNSDR_RX_H_
#define YUNSDR_RX_H_

struct global_param adc_param;
struct ring_buf *cb_adc;
int client_connect;
unsigned int adc_mode = E_GNURADIO_MODE;
unsigned int adc_state = E_STATE_UNINIT;
pthread_t thread_adc, thread_send;
char buffer[16384];
uint8_t *buf;
struct dma_dev s2m_dev;
/**
 * Function declaration
 */
void *thread_adc_func(void *arg);
void *thread_sendto_func(void *arg);
int recv_msg(long int msgtype, unsigned int *param);
static void sig_pipe(int signo);
static void sig_usr1(int signo);

#endif /* YUNSDR_RX_H_ */
