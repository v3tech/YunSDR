/**
 * $Id: snowleosdr_rx_main.c 2015-1
 *
 * @brief SNOWleo SDR RX main Module.
 *
 * @Author Eric <gaocc@v3best.com>
 *
 * (c) V3best  http://www.zingsoc.com
 *
 * This part of code is written in C programming language.
 * Please visit http://en.wikipedia.org/wiki/C_(programming_language)
 * for more details on the language used herein.
 */
#define _GNU_SOURCE 1

#include <signal.h>
#include <arpa/inet.h>
#include <yunsdr_hw.h>
#include <yunsdr_sw.h>
#include <linux/ioctl.h>
#include <linux/tcp.h>
#include <sys/msg.h>
#include <yunsdr.h>
#include "yunsdr_rx.h"



int main (int argc, char *argv[])
{

	int ret, i, flag;
	int nSendBufLen = 1*1024*1024;

	dma_dbg(MSG_DEBUG,"RX:Build: %s  %s\n", __TIME__, __DATE__);

	if (signal(SIGPIPE, sig_pipe) == SIG_ERR) {
		dma_dbg(MSG_ERROR,"RX:can't catch SIGPIPE\n");
		exit(1);
	}
	if (signal(SIGUSR1, sig_usr1) == SIG_ERR) {
		dma_dbg(MSG_ERROR,"RX:can't catch SIGUSR1\n");
		exit(1);
	}

	s2m_dev.fd = -1;
	s2m_dev.membase = NULL;
	s2m_dev.mode = M_UNINIT;
	s2m_dev.regbase = NULL;
	s2m_dev.dir = S2MM_CHANNEL;
	if(init_s2m_channel(&s2m_dev) == R_ERROR) {
		return R_ERROR;
	}
	buf = (uint8_t *)malloc(S2MM_BUF_SIZE/2);
	/**
	 * Simple ring buffer
	 */

	cb_adc = (struct ring_buf *)malloc(sizeof(struct ring_buf));
	cb_adc->front=cb_adc->rear=0;
#if 0
	uint8_t *cb_base = s2m_dev.membase + (20 *1024 *1024);
#else
	uint8_t *cb_base = malloc(MM2S_BUF_SIZE/2);
#endif
	for(i = 0; i < MaxSize; i++)
		cb_adc->data[i] = cb_base + (i * BUFFER_MAX_SIZE);

	/************************adc tcp socket**********************/
	adc_param.sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(adc_param.sockfd == -1)
	{
		dma_dbg(MSG_ERROR,"RX:socket error:%s\n",strerror(errno));
		return -1;
	}

	/* Disable the Nagle (TCP No Delay) algorithm */
	flag = 1;
	ret = setsockopt(adc_param.sockfd, IPPROTO_TCP, TCP_NODELAY, (char *)&flag, sizeof(flag) );
	if (ret == -1) {
	  printf("Couldn't setsockopt(TCP_NODELAY)\n");
	}

	bzero(&adc_param.server_addr, sizeof(adc_param.server_addr));
	adc_param.server_addr.sin_family = AF_INET;
	adc_param.server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	adc_param.server_addr.sin_port = htons(5004);
	ret = bind(adc_param.sockfd, (struct sockaddr *)&(adc_param.server_addr), sizeof(adc_param.server_addr));
	if(ret == -1)
	{
		dma_dbg(MSG_ERROR,"RX:bind error:%s\n", strerror(errno));
		return -1;
	}

	ret = listen(adc_param.sockfd, 1);
	if(ret == -1)
	{
		dma_dbg(MSG_ERROR,"RX:listen error\n");
		return -1;
	}
	adc_param.client_len = sizeof(struct sockaddr);

	while(1){
		adc_param.clifd =accept(adc_param.sockfd, (struct sockaddr *)&(adc_param.client_addr),
				&(adc_param.client_len));
		if(adc_param.clifd == -1)
		{
			dma_dbg(MSG_ERROR,"RX:accept error!\n");
		}else{
			dma_dbg(MSG_DEBUG,"RX:rx client connect!\n");
		}
		client_connect = E_CLIENT_CONNECT;
		setsockopt(adc_param.clifd, SOL_SOCKET, SO_SNDBUF, (const char *)&nSendBufLen, sizeof(int) );

		if(recv_msg(2, &adc_mode) < 0){
			dma_dbg(MSG_ERROR,"RX:recv msg failed\n");
			close(adc_param.clifd);
			client_connect = E_CLIENT_DISCONNECT;
			dma_dbg(MSG_DEBUG,"RX:connect close!\n");
			continue;
		}
		if(adc_mode == E_GNURADIO_MODE){
			ret = pthread_create(&thread_send, NULL, &thread_sendto_func, NULL);
			if (ret)
			{
				dma_dbg(MSG_ERROR,"RX:ERROR,return code from pthread_create() is %d\n", ret);
				return -1;
			}
			ret = pthread_create(&thread_adc, NULL, &thread_adc_func, &adc_mode);
			if (ret)
			{
				dma_dbg(MSG_ERROR,"RX:ERROR,return code from pthread_create() is %d\n", ret);
				return -1;
			}

			pthread_join(thread_adc,NULL);
			pthread_join(thread_send,NULL);
			cb_adc->front=cb_adc->rear=0;
		}
		if(adc_mode == E_MATLAB_MODE){
			ret = pthread_create(&thread_adc, NULL, &thread_adc_func, &adc_mode);
			if (ret)
			{
				dma_dbg(MSG_ERROR,"RX:ERROR,return code from pthread_create() is %d\n", ret);
				return -1;
			}
			pthread_join(thread_adc, NULL);
			close(adc_param.clifd);
			client_connect = E_CLIENT_DISCONNECT;
			dma_dbg(MSG_DEBUG,"RX:connect close!\n");
		}
	}
	return 0;
}

/**
 * @brief  recv data from axi dma ipcore thread.
 *
 * @param[in]  temp               user parameters
 * @retval                        NULL
 *
 */
void *thread_adc_func(void *arg)
{
	//pthread_detach(pthread_self());

	cpu_set_t mask ;
	CPU_ZERO(&mask);
	CPU_SET(2,&mask);
	int ret = 0;
	unsigned int mode = *((unsigned int *)arg);

	ret =pthread_setaffinity_np(pthread_self(),sizeof(mask),(const cpu_set_t*)&mask );
	if(ret < 0)
		dma_dbg(MSG_ERROR,"RX:ADC thread:pthread_setaffinity_np error... \n");

	if(mode == E_GNURADIO_MODE){
		adc_state = E_STATE_GNURADIO;
		dma_dbg(MSG_DEBUG,"RX:ADC:Normal mode is running!\n");
		while(client_connect)
		{
			if((cb_adc->rear+1)%MaxSize==cb_adc->front)
			{
				dma_dbg(MSG_WARNING,"RX:cb_adc full!\n");
				sleep(0);
				continue;
			}
			else
			{
				read_samples(&s2m_dev, cb_adc->data[cb_adc->rear], PACKET_SIZE*2*4, M_NORMAL);
				cb_adc->rear=(cb_adc->rear+1)%MaxSize;
			}
		}
		hw_reset(&s2m_dev);
	}
	if(mode == E_MATLAB_MODE){
		int nbyte = 0;
		uint32_t len = 0, mark;
		adc_state = E_STATE_MATLAB;

		do{
			if(recv_msg(2, &len) < 0){
				dma_dbg(MSG_DEBUG,"RX:ADC:recv msg failed!\n");
				break;
			}

			if(recv_msg(2, &mark) < 0){
				dma_dbg(MSG_DEBUG,"RX:ADC:recv msg failed!\n");
				break;
			}
			if(mark == 0xff){
				dma_dbg(MSG_DEBUG,"RX:ADC:recv stop adc thread msg!\n");
				break;
			}
			if(read_samples(&s2m_dev, buf, len, M_LOOPBACK) == R_ERROR)
				continue;
			nbyte = send(adc_param.clifd, buf, len, 0);
			if(nbyte < 0 && errno == 32){
				/* Broken_PIPE=32, client closed */
				dma_dbg(MSG_DEBUG,"RX:send:errno=%s\n", strerror(errno));
				break;
			}
		}while(1);
	}

	return NULL;
}
void *thread_sendto_func(void *arg)
{
	int ret = 0, nbyte = 0;
	cpu_set_t mask ;
	CPU_ZERO(&mask);
	CPU_SET(1, &mask);

	ret =pthread_setaffinity_np(pthread_self(),sizeof(mask),(const cpu_set_t*)&mask );
	if(ret < 0)
		dma_dbg(MSG_ERROR,"RX:pthread_setaffinity_np error... \n");

	while(1){
		if(cb_adc->front==cb_adc->rear)
		{
			//dma_dbg(MSG_WARNING,"cb_adc empty!\n");
			//pthread_mutex_unlock(&lock);
			//sleep(0);
			continue;
		}
		else
		{
			memcpy(buffer, cb_adc->data[cb_adc->front], BUFFER_MAX_SIZE);
			nbyte = send(adc_param.clifd, buffer, BUFFER_MAX_SIZE, 0);
			//nbyte = send(adc_param.clifd, cb_adc->data[cb_adc->front], BUFFER_MAX_SIZE, 0);
			if(nbyte < 0 && errno == 32){
				/* Broken_PIPE=32, client closed */
				dma_dbg(MSG_ERROR,"RX:send:errno=%s\n", strerror(errno));
				close(adc_param.clifd);
				client_connect = E_CLIENT_DISCONNECT;
				break;
			}
			cb_adc->front=(cb_adc->front+1)%MaxSize;
		}
	}
	return NULL;
}


/**
 * @brief  SIGPIPE handle.to avoid program quit from wrong network connection
 *
 * @param[in]  signo              signal id
 * @retval                        void
 *
 */
static void sig_pipe(int signo)
{
	/*nothing to do*/
}
static void sig_usr1(int signo)
{
	//unmap_memory(adc_mem_addr, S2MM_BUF_SIZE);
	//unmap_memory(dma_reg_addr_wr, REG_SIZE);
	free(cb_adc);
	exit(1);
}

int recv_msg(long int msgtype, unsigned int *param)
{
	int msgid = -1;
	struct msg_st data;
	//long int msgtype = 2;


	msgid = msgget((key_t)1234, 0666 | IPC_CREAT);
	if(msgid == -1)
	{
		dma_dbg(MSG_ERROR,"RX:msgget failed with error: %d\n", errno);
		return -1;
	}

	if(msgrcv(msgid, (void*)&data, sizeof(struct msg_st), msgtype, 0) == -1)
	{
		dma_dbg(MSG_ERROR,"RX:msgrcv failed with errno: %d\n", errno);
		return -1;
	}
	if(param != NULL)
		*param = data.param;

	return 0;
}
