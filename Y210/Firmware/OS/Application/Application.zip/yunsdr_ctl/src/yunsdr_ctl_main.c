/**
 * $Id: yunsdr_main.c 2014-5
 *
 * @brief YunSDR main Module.
 *
 * @Author jacky <gaocc@v3best.com>
 *
 * (c) V3best  http://www.zingsoc.com
 *
 * This part of code is written in C programming language.
 * Please visit http://en.wikipedia.org/wiki/C_(programming_language)
 * for more details on the language used herein.
 */
#define _GNU_SOURCE 1

#include <signal.h>
#include <arpa/inet.h>
#include <sys/msg.h>
#include <yunsdr.h>
#include <v3best/yunsdr_hw.h>
#include <v3best/yunsdr_sw.h>
#include <v3best/custom_rf_ctl.h>
#include <ad9361-hw/console_commands/command.h>


extern custom_command	custom_cmd_list[];
extern command	  		cmd_list[];
double		 			sdr_param[5]		 = {0, 0, 0, 0, 0};
char					sdr_param_no		 =  0;


/**/
#define  PACKAGE_HEAD         0xF0
#define  SDR_HANDSHAKE        0x16
#define  SDR_HANDSHAKE2       0x17
#define  SDR_ADF4001_CONFIG   0x18
#define  SDR_TX_CHANNEL_SEL   0x20
#define  SDR_RX_CHANNEL_SEL   0x21
#define  SDR_CUSTOM_CMD       0x22


/**/
enum {
	E_TX,
	E_RX,
};

enum {
	SDR_DEVICE_Y300 = 300,
	SDR_DEVICE_Y310 = 310,
};

unsigned int device_type;
struct global_param cmd_param;
unsigned int cmd_buff[2];
pthread_t thread_cmd;
unsigned char *regbase;

/**
 * Function declaration
 */
void *thread_cmd_func(void *arg);
static void sig_pipe(int signo);
int send_msg(long int msg_type, unsigned int param);


int main (int argc, char *argv[])
{

	int ret;

	dma_dbg(MSG_DEBUG,"CMD:Build: %s  %s\n", __TIME__, __DATE__);

	if (signal(SIGPIPE, sig_pipe) == SIG_ERR)
	{
		dma_dbg(MSG_ERROR,"CMD:can't catch SIGPIPE\n");
		exit(1);
	}

	/**
	 * Memory Mapping
	 */

	//regbase = map_memory(AXI_DMA_BASE_WR, REG_SIZE);
	regbase = init_hw_control();
	device_type = ioread32((unsigned long)regbase + 0x18);
	if(device_type == SDR_DEVICE_Y300){
		dma_dbg(MSG_DEBUG,"CMD:DEVICE TYPE: Y300.\n");
	}else if(device_type == SDR_DEVICE_Y310){
		dma_dbg(MSG_DEBUG,"CMD:DEVICE TYPE: Y310.\n");
	}else{
		dma_dbg(MSG_DEBUG,"CMD:DEVICE TYPE: Unknown device.\n");
		device_type = SDR_DEVICE_Y310;
	}

	/* ad9361 init */
	ad9361_main(device_type);
	if(device_type == SDR_DEVICE_Y310){
		custom_rf_ctl_init();
		adf4001_spi_setup();
	}
	/*******************cmd udp socket**************************/
	// Init socket
	cmd_param.server_addr.sin_family=AF_INET;
	cmd_param.server_addr.sin_port = htons(5006);
	cmd_param.server_addr.sin_addr.s_addr = htonl(INADDR_ANY);

	cmd_param.sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if(cmd_param.sockfd < 0){
		dma_dbg(MSG_ERROR,"CMD:ERROR,create socket failed\n");
	}

	if(bind(cmd_param.sockfd, (struct sockaddr *)&(cmd_param.server_addr), sizeof(cmd_param.server_addr)) < 0)
		perror("bind");
	/************************************************************/
	ret = pthread_create(&thread_cmd, NULL, &thread_cmd_func, NULL);
	if (ret)
	{
		dma_dbg(MSG_ERROR,"CMD:ERROR,return code from pthread_create() is %d\n", ret);
		return -1;
	}

	pthread_join(thread_cmd,NULL);

	return 0;
}

/**
 * @brief  recv command from network connection.
 *
 * @param[in]  temp               user parameters
 * @retval                        NULL
 *
 */
void *thread_cmd_func(void *arg)
{

	while(1)
	{
		recvfrom(cmd_param.sockfd, (unsigned char *)&cmd_buff, sizeof(unsigned int)*2,
				0, (struct sockaddr*)&(cmd_param.client_addr), &(cmd_param.client_len));

		dma_dbg(MSG_DEBUG,"CMD:cmd[0] = 0x%x, cmd[1] = 0x%x\n", cmd_buff[0], cmd_buff[1]);
		if((cmd_buff[0]&0xFF000000)>>24!= PACKAGE_HEAD)
		{
			memset((unsigned char *)cmd_buff, 0, sizeof(unsigned int)*2);
			perror("package error!\n");
			continue;
		}

		switch ((cmd_buff[0]&0x00FF0000)>>16)
		{
		case SDR_HANDSHAKE:
		{
			long int msg_type;
			if((cmd_buff[0]&0x0000FF00)>>8 == E_TX){
				if((cmd_buff[0]&0x000000FF) == E_GNURADIO_MODE){
					msg_type = 1;
					if(send_msg(msg_type, E_GNURADIO_MODE) < 0){
						dma_dbg(MSG_ERROR,"CMD:send msg failed!\n");
						break;
					}
					dma_dbg(MSG_DEBUG, "CMD:TX: E_GNURADIO_MODE\n");
				}
				if((cmd_buff[0]&0x000000FF) == E_MATLAB_MODE){
					msg_type = 1;
					if(send_msg(msg_type, E_MATLAB_MODE) < 0){
						dma_dbg(MSG_ERROR,"send msg failed!\n");
						break;
					}
					dma_dbg(MSG_DEBUG, "CMD:TX: E_MATLAB_MODE\n");
				}
				break;
			}
			if((cmd_buff[0]&0x0000FF00)>>8 == E_RX){
				if((cmd_buff[0]&0x000000FF) == E_GNURADIO_MODE){
					msg_type = 2;
					if(send_msg(msg_type, E_GNURADIO_MODE) < 0){
						dma_dbg(MSG_ERROR,"CMD:send msg failed!\n");
						break;
					}
					dma_dbg(MSG_DEBUG, "CMD:RX: E_GNURADIO_MODE\n");
				}
				if((cmd_buff[0]&0x000000FF) == E_MATLAB_MODE){
					msg_type = 2;
					if(send_msg(msg_type, E_MATLAB_MODE) < 0){
						dma_dbg(MSG_ERROR,"CMD:send msg failed!\n");
						break;
					}
					dma_dbg(MSG_DEBUG, "CMD:RX: E_MATLAB_MODE\n");
				}
				break;
			}
		}
		case SDR_HANDSHAKE2:
		{
			long int msg_type;

			if((cmd_buff[0]&0x0000FF00)>>8 == E_TX){
				if((cmd_buff[0]&0x000000FF) != 0xFF){
					msg_type = 3;
					if(send_msg(msg_type, cmd_buff[1]) < 0){
						dma_dbg(MSG_ERROR,"CMD:send msg failed!\n");
						break;
					}
				}else{
					dma_dbg(MSG_DEBUG, "CMD:TX:MATLAB_MODE:STOP TX ...\n");
					msg_type = 5;
					if(send_msg(msg_type, 0xFF) < 0){
						dma_dbg(MSG_ERROR,"CMD:send msg failed!\n");
						break;
					}
				}
				break;
			}

			if((cmd_buff[0]&0x0000FF00)>>8 == E_RX){
				msg_type = 2;
				if(send_msg(msg_type, cmd_buff[1]) < 0){
					dma_dbg(MSG_ERROR,"CMD:send msg failed!\n");
					break;
				}
				msg_type = 2;/*start adc or stop adc*/
				if(send_msg(msg_type, cmd_buff[0]&0x000000FF) < 0){
					dma_dbg(MSG_ERROR,"CMD:send msg failed!\n");
					break;
				}
				if((cmd_buff[0]&0x000000FF) == 0xFF){
					dma_dbg(MSG_DEBUG, "CMD:RX:MATLAB_MODE:STOP RX ...\n");
				}else{
					dma_dbg(MSG_DEBUG, "CMD:RX:MATLAB_MODE:START RX ...\n");
				}

				break;
			}
		}
		case SDR_TX_CHANNEL_SEL:
			iowrite32((ioread32((unsigned long)regbase + 0x10)&(~0x3))|(cmd_buff[0]&0x03),
					(unsigned long)regbase + 0x10);
			dma_dbg(MSG_DEBUG,"CMD:recv SDR_TX_CHANNEL_SEL cmd\n");
			break;
		case SDR_RX_CHANNEL_SEL:
			iowrite32((ioread32((unsigned long)regbase + 0x10)&(~0xC))|((cmd_buff[0]&0x03)<<2),
					(unsigned long)regbase + 0x10);
			dma_dbg(MSG_DEBUG,"CMD:recv SDR_RX_CHANNEL_SEL cmd\n");
			break;
		case SDR_ADF4001_CONFIG:
			if(device_type == SDR_DEVICE_Y310){
				adf4001_prep_data((cmd_buff[1]&0xFFFF0000)>>16,(cmd_buff[1]&0x0000FFFF));
				adf4001_spi_setup();
			}
			dma_dbg(MSG_DEBUG,"CMD:recv SDR_RX_CHANNEL_SEL cmd\n");
			break;

		case SDR_CUSTOM_CMD:
		{
			unsigned char cmd = (cmd_buff[0]&0x0000FF00)>>8;
			if(cmd >= 0 && cmd < 30) {
				if(cmd == 3 || cmd == 15){
					sdr_param[0] = (uint64_t)cmd_buff[1]|(((uint64_t)cmd_buff[0]&0x000000FF)<<32);
					printf("freq = %llu\n", (uint64_t)sdr_param[0]);
				}else{
					sdr_param[0] = cmd_buff[1];
				}

				sdr_param_no = 1;
				cmd_list[cmd].function(sdr_param, sdr_param_no);
				if(device_type == SDR_DEVICE_Y310){
					if(cmd == 3){
						tx_band_sel((uint64_t)sdr_param[0]);
						tx_rf_port_input_select((uint64_t)sdr_param[0]);
					}
					if(cmd == 15){
						rx1_band_sel((uint64_t)sdr_param[0]);
						rx2_band_sel((uint64_t)sdr_param[0]);
						rx_rf_port_input_select((uint64_t)sdr_param[0]);
					}
				}
			}
			else if(cmd >= 40 && cmd <= 45) {
				if(device_type == SDR_DEVICE_Y310){
					custom_cmd_list[cmd-40].function(cmd_buff[1]);
				}
			}
			else
				dma_dbg(MSG_WARNING,"CMD:undefined command!\n");
			dma_dbg(MSG_DEBUG,"CMD:recv SDR_CUSTOM cmd\n");
			break;
		}
		default:
			break;
		}

		memset((unsigned char *)cmd_buff, 0, sizeof(unsigned int)*2);
	}

	return NULL;
}

/**
 * @brief  SIGPIPE handle.to avoid program quit from wrong network connection
 *
 * @param[in]  signo              signal id
 * @retval                        void
 *
 */
static void sig_pipe(int signo)
{
	/*nothing to do*/
}
int send_msg(long int msg_type, unsigned int param)
{
	struct msg_st data;
	int msgid = -1;


	msgid = msgget((key_t)1234, 0666 | IPC_CREAT);
	if(msgid == -1)
	{
		dma_dbg(MSG_ERROR, "CMD:msgget failed with error: %d\n", errno);
		return -1;
	}
	data.msg_type = msg_type;
	data.param = param;

	if(msgsnd(msgid, (void*)&data, sizeof(struct msg_st), 0) == -1)
	{
		dma_dbg(MSG_ERROR, "CMD:msgsnd failed\n");
		return -1;
	}
	return 0;
}
