/*
 * main.h
 *
 *  Created on: 2015��9��9��
 *      Author: Eric
 */
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#define _GNU_SOURCE
#include <sched.h>

#ifdef WIN32
#include <winsock2.h>
#include <windows.h>
//#pragma comment(lib, "ws2_32.lib")
#else
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#endif
#define DATA_SIZE  16384
#define FRAME_HEAD_IN_BYTE 24
#define FRAME_SIZE (DATA_SIZE+FRAME_HEAD_IN_BYTE)

#define NUM_OF_FILE  13
#define DATA_FILE_TONE_1 "tone_16bit.dat"
#define DATA_FILE_TONE_2 "tone_16bit_2ch.dat"
#define DATA_FILE      "data.dat"
#define DATA_FILE1x1_1 "simple11a3_12mbps_100byte.dat"
#define DATA_FILE1x1_2 "simple11a3_12mbps_200byte.dat"
#define DATA_FILE1x1_3 "simple11a3_12mbps_300byte.dat"
#define DATA_FILE1x1_4 "simple11a3_12mbps_400byte.dat"
#define DATA_FILE4x4_1 "mcs31_20_400byte_ch1_2.dat"
#define DATA_FILE4x4_2 "mcs31_20_400byte_ch3_4.dat"
#define DATA_FILE4x4_3 "mcs27_20_1000byte_ch1_2.dat"
#define DATA_FILE4x4_4 "mcs27_20_1000byte_ch3_4.dat"
#define DATA_FILE4x4_5 "mcs26_20_400byte_ch1_2.dat"
#define DATA_FILE4x4_6 "mcs26_20_400byte_ch3_4.dat"
#define DATA_FILE2x2_1 "mcs11_20_100byte.dat"
char *dat_name[NUM_OF_FILE] = {
		DATA_FILE1x1_1,
		DATA_FILE1x1_2,
		DATA_FILE1x1_3,
		DATA_FILE1x1_4,
		DATA_FILE_TONE_1,
		DATA_FILE_TONE_2,
		DATA_FILE4x4_1,
		DATA_FILE4x4_2,
		DATA_FILE4x4_3,
		DATA_FILE4x4_4,
		DATA_FILE4x4_5,
		DATA_FILE4x4_6,
		DATA_FILE2x2_1,
};

#define TX_BUF_SIZE (16*1024*1024)
//#define RX_BUF_SIZE (240*1024*1024)

enum {
	START_TX_NORMAL = 01,
	START_TX_LOOP = 02,
	START_RX_NORMAL = 03,
};
enum {
	START_TX_ONLY = 01,
	START_RX_ONLY = 02,
	START_TRX_BOTH = 03,
};
struct msg_head {
	uint32_t control;
	uint32_t param1;
	uint32_t param2;
	uint32_t payload;
};

char *ipaddr[14] = {
		/*"192.168.1.10",
		"192.168.1.11",*/
		"192.168.1.12",
		"192.168.1.13",
		"192.168.1.14",
		"192.168.1.15",
		"192.168.1.16",
		"192.168.1.17",
		"192.168.1.18",
		"192.168.1.19",
		"192.168.1.20",
		"192.168.1.21",
		"192.168.1.22",
		"192.168.1.23",
};

struct rf_param {
	uint64_t tx_freq;
	uint32_t tx_atten;
	uint32_t tx_bw;
	uint32_t tx_samprate;

	uint64_t rx_freq;
	uint32_t rx_gain;
	uint32_t rx_bw;
	uint32_t rx_samprate;

	uint32_t ref;
	uint32_t vco;
	uint32_t adf_clk;
};

int GetProfileVal(char *profile, char *AppName, char *KeyName, long long *KeyVal);

long long yunsdr_ticksToTimeNs(const long long ticks, const double rate)
{
	const long long ratell = (long long)(rate);
	const long long full = (long long)(ticks/ratell);
	const long long err = ticks - (full*ratell);
	const double part = full*(rate - ratell);
	const double frac = ((err - part)*1000000000)/rate;
	return (full*1000000000) + llround(frac);
}
long long yunsdr_timeNsToTicks(const long long timeNs, const double rate)
{
	const long long ratell = (long long)(rate);
	const long long full = (long long)(timeNs/1000000000);
	const long long err = timeNs - (full*1000000000);
	const double part = full*(rate - ratell);
	const double frac = part + ((err*rate)/1000000000);
	return (full*ratell) + llround(frac);
}

#ifdef WIN32
SOCKET init_socket(const char *ip, int port)
#else
int init_socket(const char *ip, int port)
#endif
{
	int err;
#ifdef WIN32
	SOCKET sockfd;
	SOCKADDR_IN addr;
#else
	struct sockaddr_in addr;
	int sockfd;
#endif
	/********************tx tcp**********************/
	memset(&addr, 0, sizeof(addr));
	if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) <= 0)
	{
		printf("Create tx socket fail!\n");
		return -1;
	}
#ifndef WIN32
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = inet_addr(ip);
	addr.sin_port = htons(port);
#else
	addr.sin_addr.S_un.S_addr = inet_addr(ip);
	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
#endif
	int nSendBufLen = 20*1024*1024;
	int nRecvBufLen = 0;
	int len = sizeof(nRecvBufLen);
	err = setsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, (const char *)&nSendBufLen, sizeof(int));
	if(err < 0){
		printf("setsockopt SO_SNDBUF failed, %s!\n", strerror(errno));
	}

	err = setsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, (const char *)&nSendBufLen, sizeof(int));
	if(err < 0){
		printf("setsockopt SO_RCVBUF failed, %s!\n", strerror(errno));
	}
	err = getsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, (char *)&nRecvBufLen, &len);
	if(err < 0){
		printf("getsockopt SO_RCVBUF failed, %s!\n", strerror(errno));
	} else {
		printf("socket recv buf size:%d\n", nRecvBufLen);
	}
	err=connect(sockfd, (struct sockaddr *)&addr, sizeof(addr));
	if(err < 0){
		printf("client connect failed!\n");
	}

	return sockfd;
}

#if 0
uint64_t rf_init(const char *ip, int op)
{
	int ret;
	/********************cmd udp**********************/
#ifdef WIN32
	SOCKET cmd_sock;
	SOCKADDR_IN cmd_addr;
	int addr_len = sizeof(SOCKADDR_IN);
#else
	struct sockaddr_in cmd_addr;
	int cmd_sock;
	socklen_t addr_len = sizeof(struct sockaddr_in);
#endif

	memset(&cmd_addr, 0, sizeof(cmd_addr));
	if((cmd_sock = socket(AF_INET, SOCK_DGRAM, 0)) <= 0)
	{
		printf("Create cmd socket fail!\n");
		return -1;
	}
#ifndef WIN32
	cmd_addr.sin_family = AF_INET;
	cmd_addr.sin_addr.s_addr = inet_addr(ip);
	cmd_addr.sin_port = htons(5006);
#else
	cmd_addr.sin_addr.S_un.S_addr = inet_addr(ip);
	cmd_addr.sin_family = AF_INET;
	cmd_addr.sin_port = htons(5006);
#endif

	uint32_t cmd[2];
	if(op == 1){
#define		TX_CONFIG
#ifdef TX_CONFIG
		uint64_t val;
		int ret;
		struct rf_param param;

		ret = GetProfileVal("config.conf", "RF", "tx_freq", &val);
		if(ret < 0)
			param.tx_freq = 2400000000UL;
		else
			param.tx_freq = val;
		ret = GetProfileVal("config.conf", "RF", "tx_atten", &val);
		if(ret < 0)
			param.tx_atten = 10000;
		else
			param.tx_atten = val;
		ret = GetProfileVal("config.conf", "RF", "tx_bw", &val);
		if(ret < 0)
			param.tx_bw = 20e6;
		else
			param.tx_bw = val;
		ret = GetProfileVal("config.conf", "RF", "tx_samprate", &val);
		if(ret < 0)
			param.tx_samprate = 40e6;
		else
			param.tx_samprate = val;
		ret = GetProfileVal("config.conf", "RF", "rx_freq", &val);
		if(ret < 0)
			param.rx_freq = 2400000000UL;
		else
			param.rx_freq = val;
		ret = GetProfileVal("config.conf", "RF", "rx_gain", &val);
		if(ret < 0)
			param.rx_gain = 5;
		else
			param.rx_gain = val;
		ret = GetProfileVal("config.conf", "RF", "rx_bw", &val);
		if(ret < 0)
			param.rx_bw = 20e6;
		else
			param.rx_bw = val;
		ret = GetProfileVal("config.conf", "RF", "rx_samprate", &val);
		if(ret < 0)
			param.rx_samprate = 40e6;
		else
			param.rx_samprate = val;
		ret = GetProfileVal("config.conf", "RF", "ref", &val);
		if(ret < 0)
			param.ref = 0;
		else
			param.ref = val;
		ret = GetProfileVal("config.conf", "RF", "vco", &val);
		if(ret < 0)
			param.vco = 0;
		else
			param.vco = val;
		ret = GetProfileVal("config.conf", "RF", "adf_clk", &val);
		if(ret < 0)
			param.adf_clk = 0;
		else
			param.adf_clk = val;

		//tx bandwidth rate
		cmd[0] = 0xf0220000|(7<<8);
		cmd[1] = param.tx_bw;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//tx samp rate
		cmd[0] = 0xf0220000|(5<<8);
		cmd[1] = param.tx_samprate;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//send tx freq set cmd
		//tx_freq=[hex2dec(freq_hex(1:2)) 3 hex2dec('22') hex2dec('f0') hex2dec(freq_hex(9:10)) hex2dec(freq_hex(7:8)) hex2dec(freq_hex(5:6)) hex2dec(freq_hex(3:4))];
		cmd[0] = 0xf0220000|(3<<8);
		cmd[1] = param.tx_freq;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//send tx atten set cmd
		cmd[0] = 0xf0220000|(9<<8);
		cmd[1] = param.tx_atten;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		cmd[0] = 0xf0220000|(11<<8);
		cmd[1] = param.tx_atten;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
#endif
		//rx bandwidth rate
		cmd[0] = 0xf0220000|(19<<8);
		cmd[1] = param.rx_bw;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//rx samp rate
		cmd[0] = 0xf0220000|(17<<8);
		cmd[1] = param.rx_samprate;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//send rx freq
		//rx_freq=[hex2dec(freq_hex(1:2)) 15 hex2dec('22') hex2dec('f0') hex2dec(freq_hex(9:10)) hex2dec(freq_hex(7:8)) hex2dec(freq_hex(5:6)) hex2dec(freq_hex(3:4))];
		cmd[0] = 0xf0220000|(15<<8);
		cmd[1] = param.rx_freq;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//agc mode
		cmd[0] = 0xf0220000|(21<<8);
		cmd[1] = 0;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		cmd[0] = 0xf0220000|(23<<8);
		cmd[1] = 0;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//send rx vga
		cmd[0] = 0xf0220000|(25<<8);
		cmd[1] = param.rx_gain;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		cmd[0] = 0xf0220000|(27<<8);
		cmd[1] = param.rx_gain;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));

		//ref_select
		cmd[0] = 0xf0220000|(40<<8);
		cmd[1] = param.ref;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//vco_cal_select
		cmd[0] = 0xf0220000|(41<<8);
#ifdef TWO_CLIENT
		cmd[1] = 0;
#else
		cmd[1] = 0;
#endif
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//fdd_tdd_select
		cmd[0] = 0xf0220000|(42<<8);
		cmd[1] = 1;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//trx_sw
		cmd[0] = 0xf0220000|(43<<8);
		cmd[1] = 1;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//adf4001
#ifdef ADF4001_26M
		cmd[0] = 0xf0220000|(45<<8);
		cmd[1] = (26<<16)|26;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
#endif
	}
	if(op == 2){
		cmd[0] = 0xf0230000;
		cmd[1] = 1;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
	}
	if(op == 3){
		cmd[0] = 0xf0230000;
		cmd[1] = 0;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		ret = recvfrom(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, &addr_len);
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		else
			printf("timestamp = %lld\n", ((uint64_t)cmd[1]<<32)+cmd[0]);

	}
#ifdef WIN32
	Sleep(1);
#else
	usleep(1e4);
#endif

#ifdef WIN32
	closesocket(cmd_sock);
#else
	close(cmd_sock);
#endif
	if(op == 3)
		return ((uint64_t)cmd[1]<<32)+cmd[0];
	return 0;
}
#endif
