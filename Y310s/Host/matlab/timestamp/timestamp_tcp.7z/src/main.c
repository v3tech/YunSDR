//UDP client

#include "main.h"
#ifdef WIN32
#define MSG_WAITALL  0
#else
#define SOCKET int
#endif

extern int ping_proc(char *ip);
uint64_t config_handler(const char *ip, int op);
int tx_test(SOCKET sockfd,  uint8_t *tx_buffer, uint32_t nbyte, uint64_t timestamp);
int rx_test(SOCKET sockfd,  uint8_t *tx_buffer, uint32_t nbyte, uint64_t timestamp);
SOCKET init_socket(const char *ip, int port);
void print_help();

struct thread_param {
	SOCKET tx_sock;
	SOCKET rx_sock;
	char ipaddr[20];
	uint32_t id;
	int32_t mark;
	int32_t op;
	int32_t status;
	int32_t trx;
};
char *f_name[NUM_OF_FILE];

#define NUM_OF_CLIENT 2
pthread_t thread[NUM_OF_CLIENT];
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

void *thread_main(void *arg);
void *thread_trx(void *arg);

uint64_t timestamp1;
uint32_t file_id = 0;

#define DUAL_CH
#define REF_CLK 0
//#define ADF4001_26M
#define TX_TIMESTAMP_OFFSET 400000
#define RX_TIMESTAMP_OFFSET 399500
#define RX_SIZE_IN_BYTE  (230*1024*1024)


int main(int argc, char *argv[])
{
	int err, i;
#ifdef WIN32
	WSADATA wsa;
	WORD wVersionRequested;
	WSADATA wsaData;

	WSAStartup(MAKEWORD(2,2), &wsa);
	wVersionRequested = MAKEWORD(2, 2);

	err = WSAStartup(wVersionRequested, &wsaData);
	if (err != 0) {
		printf("WSAStartup failed with error: %d\n", err);
		return 1;
	}

	if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2) {
		printf("Could not find a usable version of Winsock.dll\n");
		WSACleanup();
		return 1;
	}
	else
		printf("The Winsock 2.2 dll was found okay\n");
#endif
	char dir[80];
	printf("%s\n", getcwd(dir, sizeof(dir)));
	for(i = 0; i < NUM_OF_FILE; i++){
		f_name[i] = (char *)malloc(150);
#ifdef WIN32
		sprintf(f_name[i], "%s\\%s", dir, dat_name[i]);
#else
		sprintf(f_name[i], "%s/%s", dir, dat_name[i]);
#endif
	}

	struct thread_param param[NUM_OF_CLIENT];
	for(i = 0; i < NUM_OF_CLIENT; i++){
		strcpy(param[i].ipaddr, ipaddr[i]);
		param[i].id = i+1;
		param[i].mark = 0;
		param[i].op = 0;
		param[i].trx = 0;
		if(ping_proc(ipaddr[i]) < 0)
			param[i].status = -1;
	}
	int ch;
	opterr=0;

	while((ch=getopt(argc, argv, "t:drseh"))!=-1)
	{
		switch(ch)
		{
		case 't':
		{
			int i, j;

			if(atoi(optarg)>=0&&atoi(optarg)<=100000){
				for(i = 0; i < NUM_OF_CLIENT; i++){
					param[i].tx_sock = init_socket(param[i].ipaddr, 5005);
					param[i].rx_sock = init_socket(param[i].ipaddr, 5004);
				}

				for(j = 0; j < atoi(optarg); j++) {
					printf("\n*************timestamp test %d*************\n", j);
					timestamp1 = config_handler(param[0].ipaddr, 3);
					int32_t ret;
					for(i = 0; i < NUM_OF_CLIENT; i++){
						param[i].trx = START_TRX_BOTH;
						ret = pthread_create(&thread[i], NULL, &thread_trx, &param[i]);
						if (ret)
						{
							printf("ERROR, return code from pthread_create() is %d\n", ret);
							return -1;
						}
					}
					for(i = 0; i < NUM_OF_CLIENT; i++){
						pthread_join(thread[i], NULL);
					}
					file_id++;
				}

				for(i = 0; i < NUM_OF_CLIENT; i++){
#ifdef WIN32
					closesocket(param[i].tx_sock);
					closesocket(param[i].rx_sock);
#else
					close(param[i].tx_sock);
					close(param[i].rx_sock);

#endif
					param[i].mark = 0;
					param[i].op = 0;
					param[i].status = 0;
				}
			}
			break;
		}
		case 'd':
		{
			printf("disable timestamp ...\n");
			int32_t op = 2;
			for(i = 0; i < NUM_OF_CLIENT; i++){
				config_handler(param[i].ipaddr, op);
			}

			break;
		}
		case 's':
		{
			printf("init radio ...\n");
			for(i = 0; i < NUM_OF_CLIENT; i++){
				config_handler(param[i].ipaddr, 0);
			}
			break;
		}
		case 'e':
		{
			printf("enable timestamp ...\n");
			int32_t ret, op = 1;
			for(i = 0; i < NUM_OF_CLIENT; i++){
				param[i].op = op;
				ret = pthread_create(&thread[i], NULL, &thread_main, &param[i]);
				if (ret)
				{
					printf("ERROR, return code from pthread_create() is %d\n", ret);
					return -1;
				}
			}
			int count = 0;
			while(1)
			{
				pthread_mutex_lock(&lock);
				for(i = 0; i < NUM_OF_CLIENT; i++){
					if(param[i].mark > 0)
						count += 1;
				}
				if(count == NUM_OF_CLIENT)
				{
					pthread_cond_broadcast(&cond);
					for(i = 0; i < NUM_OF_CLIENT; i++){
						param[i].mark = 0;
					}
					pthread_mutex_unlock (&lock);
					break;
				}
				else
					count = 0;
				pthread_mutex_unlock(&lock);
			}
			for(i = 0; i < NUM_OF_CLIENT; i++){
				pthread_join(thread[i], NULL);
				param[i].mark = 0;
				param[i].op = 0;
				param[i].status = 0;
			}
			break;
		}
		case 'r':
		{
			printf("read current timestamp ...\n");
			int32_t ret, op = 3;
			for(i = 0; i < NUM_OF_CLIENT; i++){
				param[i].op = op;
				ret = pthread_create(&thread[i], NULL, thread_main, &param[i]);
				if (ret)
				{
					printf("ERROR, return code from pthread_create() is %d\n", ret);
					return -1;
				}
			}
			int count = 0;
			while(1)
			{
				pthread_mutex_lock(&lock);
				for(i = 0; i < NUM_OF_CLIENT; i++){
					if(param[i].mark > 0)
						count += 1;
				}
				if(count == NUM_OF_CLIENT)
				{
					pthread_cond_broadcast(&cond);
					for(i = 0; i < NUM_OF_CLIENT; i++){
						param[i].mark = 0;
					}
					pthread_mutex_unlock (&lock);
					break;
				}
				else
					count = 0;
				pthread_mutex_unlock(&lock);
			}
			for(i = 0; i < NUM_OF_CLIENT; i++){
				pthread_join(thread[i], NULL);
				param[i].mark = 0;
				param[i].op = 0;
				param[i].status = 0;
			}
			break;
		}
		case 'h':
			printf("print help ...\n");
			print_help();
			break;
		default:
			printf("other option:%c\n",ch);
		}
	}

#ifdef WIN32
	WSACleanup();	//clean up Ws2_32.dll
#endif

	for(i = 0; i < NUM_OF_FILE; i++){
		free(f_name[i]);
	}
	return 0;
}

int32_t read_file(const char *filename, uint8_t *buf)
{
	int32_t nbyte;
	int32_t filesize;
	FILE *fp;
	fp=fopen(filename, "rb+");
	if(fp == NULL)
	{
		perror("fopen");
		return -1;
	}
	fseek(fp, 0, SEEK_END);
	filesize = ftell(fp);
	//printf("file size:%d \n", filesize);
	fseek(fp, 0, SEEK_SET);
	if(filesize <= (DATA_SIZE*4)){
		nbyte = fread((void *)buf, 1, filesize, fp);
		//printf("nbyte = %d\n", nbyte);
		fclose(fp);
		return nbyte;
	}
	else {
		fclose(fp);
		return -1;
	}
}
int32_t write_file(const char *filename, uint8_t *buf, uint32_t size)
{
	int32_t nbyte;
	FILE *fp;
	fp = fopen(filename, "wb+");
	if(fp == NULL)
	{
		perror("fopen");
		return -1;
	}
	nbyte = fwrite((void *)buf, 1, size, fp);
	//printf("nbyte = %d\n", nbyte);
	fclose(fp);
	return nbyte;
}

int tx_test(SOCKET sockfd,  uint8_t *tx_buffer, uint32_t nbyte, uint64_t timestamp)
{
	struct msg_head msg;
	int32_t ret;

	*((uint32_t *)tx_buffer) = 0xFF000080;
#ifdef DUAL_CH
	*((uint32_t *)tx_buffer+1) = 0x3 | 0x1<<4;
	*((uint32_t *)tx_buffer+2) = nbyte/8;
#else
	*((uint32_t *)tx_buffer+1) = 0x1 | 0x1<<4;
	*((uint32_t *)tx_buffer+2) = nbyte/4;
#endif
	*((uint32_t *)tx_buffer+3) = 0x55AAAA55;
	*((uint32_t *)tx_buffer+4) = (uint32_t)timestamp;
	*((uint32_t *)tx_buffer+5) = (uint32_t)(timestamp>>32);

	msg.control = START_TX_NORMAL;
	msg.param1 = 1;
	msg.payload = nbyte+FRAME_HEAD_IN_BYTE;

	ret = send(sockfd, (void *)&msg, sizeof(struct msg_head), 0);
	if(ret < 0)
	{
		printf("send error:%s\n", strerror(errno));
	}
	ret = send(sockfd, (void *)tx_buffer, nbyte+FRAME_HEAD_IN_BYTE, 0);
	if(ret < 0)
	{
		printf("send error:%s\n", strerror(errno));
	}
	return ret;
}

int rx_test(SOCKET sockfd, uint8_t *rx_buffer, uint32_t nbyte, uint64_t timestamp)
{
	int ret;
	uint32_t count = 0;
	struct msg_head msg;
#ifdef DUAL_CH
	msg.control = START_RX_NORMAL | 0x3<<16 | (0x1<<8);
	msg.payload = nbyte/8;
#else
	msg.control = START_NOW | 0x1<<16 | (0x1<<8);
	msg.payload = nbyte/4;
#endif
	msg.param1 = (uint32_t)timestamp;
	msg.param2 = (uint32_t)(timestamp>>32);

	send(sockfd, (void *)&msg, sizeof(struct msg_head), 0);

	do {
		ret = recv(sockfd, (void *)rx_buffer+count, nbyte+FRAME_HEAD_IN_BYTE-count, MSG_WAITALL);
		if(ret < 0) {
			printf("recv error:%s\n", strerror(errno));
			break;
		} else {
			count += ret;
		}
	} while(count != (nbyte+FRAME_HEAD_IN_BYTE));


	return count;
}

uint64_t config_handler(const char *ip, int op)
{
	int ret;
	/********************cmd udp**********************/
#ifdef WIN32
	SOCKET cmd_sock;
	SOCKADDR_IN cmd_addr;
	int addr_len = sizeof(SOCKADDR_IN);
#else
	struct sockaddr_in cmd_addr;
	int cmd_sock;
	socklen_t addr_len = sizeof(struct sockaddr_in);
#endif

	memset(&cmd_addr, 0, sizeof(cmd_addr));
	if((cmd_sock = socket(AF_INET, SOCK_DGRAM, 0)) <= 0)
	{
		printf("Create cmd socket fail!\n");
		return -1;
	}
#ifndef WIN32
	cmd_addr.sin_family = AF_INET;
	cmd_addr.sin_addr.s_addr = inet_addr(ip);
	cmd_addr.sin_port = htons(5006);
#else
	cmd_addr.sin_addr.S_un.S_addr = inet_addr(ip);
	cmd_addr.sin_family = AF_INET;
	cmd_addr.sin_port = htons(5006);
#endif

	uint32_t cmd[2];
	if(op == 0){
#define		TX_CONFIG
#ifdef TX_CONFIG
		//tx bandwidth rate
		cmd[0] = 0xf0220000|(7<<8);
		cmd[1] = 20e6;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//tx samp rate
		cmd[0] = 0xf0220000|(5<<8);
		cmd[1] = 40e6;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//send tx freq set cmd
		//tx_freq=[hex2dec(freq_hex(1:2)) 3 hex2dec('22') hex2dec('f0') hex2dec(freq_hex(9:10)) hex2dec(freq_hex(7:8)) hex2dec(freq_hex(5:6)) hex2dec(freq_hex(3:4))];
		cmd[0] = 0xf0220000|(3<<8);
		cmd[1] = 2350e6;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//send tx vga set cmd
		cmd[0] = 0xf0220000|(9<<8);
		cmd[1] = 20000;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		cmd[0] = 0xf0220000|(11<<8);
		cmd[1] = 20000;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
#endif
		//rx bandwidth rate
		cmd[0] = 0xf0220000|(19<<8);
		cmd[1] = 20e6;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//rx samp rate
		cmd[0] = 0xf0220000|(17<<8);
		cmd[1] = 40e6;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//send rx freq
		//rx_freq=[hex2dec(freq_hex(1:2)) 15 hex2dec('22') hex2dec('f0') hex2dec(freq_hex(9:10)) hex2dec(freq_hex(7:8)) hex2dec(freq_hex(5:6)) hex2dec(freq_hex(3:4))];
		cmd[0] = 0xf0220000|(15<<8);
		cmd[1] = 2350e6;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//agc mode
		cmd[0] = 0xf0220000|(21<<8);
		cmd[1] = 0;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		cmd[0] = 0xf0220000|(23<<8);
		cmd[1] = 0;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//send rx vga
		cmd[0] = 0xf0220000|(25<<8);
		cmd[1] = 5;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		cmd[0] = 0xf0220000|(27<<8);
		cmd[1] = 5;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));

		//ref_select
		cmd[0] = 0xf0220000|(40<<8);
		cmd[1] = REF_CLK;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//vco_cal_select
		cmd[0] = 0xf0220000|(41<<8);
#ifdef TWO_CLIENT
		cmd[1] = 0;
#else
		cmd[1] = 0;
#endif
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//fdd_tdd_select
		cmd[0] = 0xf0220000|(42<<8);
		cmd[1] = 1;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//trx_sw
		cmd[0] = 0xf0220000|(43<<8);
		cmd[1] = 1;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		//adf4001
#ifdef ADF4001_26M
		cmd[0] = 0xf0220000|(45<<8);
		cmd[1] = (26<<16)|26;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
#endif
	}
	if(op == 1){
		cmd[0] = 0xf0230000;
		cmd[1] = 1;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
	}
	if(op == 2){
		cmd[0] = 0xf0230000;
		cmd[1] = 2;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
	}
	if(op == 3){
		cmd[0] = 0xf0230000;
		cmd[1] = 0;
		ret = sendto(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, sizeof(cmd_addr));
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		ret = recvfrom(cmd_sock, (void *)cmd, sizeof(int)*2, 0, (struct sockaddr *)&cmd_addr, &addr_len);
		if(ret < 0)
			printf("sendto error:%s\n", strerror(errno));
		else
			printf("[%s]timestamp = %lld\n", ip, ((uint64_t)cmd[1]<<32)+cmd[0]);

	}
#ifdef WIN32
	Sleep(1);
#else
	usleep(1e4);
#endif

#ifdef WIN32
	closesocket(cmd_sock);
#else
	close(cmd_sock);
#endif
	if(op == 3)
		return ((uint64_t)cmd[1]<<32)+cmd[0];
	return 0;
}

void *thread_main(void *arg)
{
	struct thread_param *v_param = (struct thread_param *)arg;
	pthread_mutex_lock(&lock);
	v_param->mark = 1;
	pthread_cond_wait(&cond, &lock);
	pthread_mutex_unlock(&lock);
	config_handler(v_param->ipaddr, v_param->op);
	return NULL;
}

void *thread_trx(void *arg)
{
	struct thread_param  *v_param= (struct thread_param *)arg;
	char filename[50];
	sprintf(filename, "data-%d-%d.bin", v_param->id, file_id);
	switch (v_param->trx)
	{
	case START_TRX_BOTH:
	{
		uint8_t *rx_buf = malloc(RX_SIZE_IN_BYTE+FRAME_HEAD_IN_BYTE);
		if(rx_buf == NULL) {
			printf("malloc rx buf failed!\n");
			break;
		}
		uint8_t *tx_buf = malloc(TX_BUF_SIZE);
		if(tx_buf == NULL) {
			printf("malloc tx buf failed!\n");
			free(rx_buf);
			break;
		}
		int32_t nbyte;
		nbyte = read_file(f_name[12], tx_buf+FRAME_HEAD_IN_BYTE);
		if(nbyte > TX_BUF_SIZE) {
			free(tx_buf);
			free(rx_buf);
			return NULL;
		}

		nbyte = tx_test(v_param->tx_sock, tx_buf, nbyte, timestamp1+TX_TIMESTAMP_OFFSET);
		printf("[%s]transmit nbyte = %d\n", v_param->ipaddr, nbyte);
		nbyte = rx_test(v_param->rx_sock, rx_buf, RX_SIZE_IN_BYTE, timestamp1+RX_TIMESTAMP_OFFSET);
		printf("[%s]receive nbyte = %d, Frame head: 0x%x\n", v_param->ipaddr, nbyte, *((uint32_t *)rx_buf));
		write_file(filename, rx_buf, RX_SIZE_IN_BYTE+FRAME_HEAD_IN_BYTE);
		//printf("[%s]Frame head: 0x%x\n", v_param->ipaddr, *((uint32_t *)rx_buf));
		free(tx_buf);
		free(rx_buf);
		break;
	}
	case START_TX_ONLY:
	{
		uint8_t *tx_buf = malloc(TX_BUF_SIZE);
		int32_t nbyte;
		nbyte = read_file(f_name[12], tx_buf+FRAME_HEAD_IN_BYTE);
		if(nbyte > TX_BUF_SIZE) {
			free(tx_buf);
			return NULL;
		}
		tx_test(v_param->tx_sock, tx_buf, nbyte, timestamp1+TX_TIMESTAMP_OFFSET);
		free(tx_buf);
		break;
	}
	case START_RX_ONLY:
	{
		uint8_t *rx_buf = malloc(RX_SIZE_IN_BYTE+FRAME_HEAD_IN_BYTE);
		rx_test(v_param->rx_sock, rx_buf, RX_SIZE_IN_BYTE, timestamp1+RX_TIMESTAMP_OFFSET);
		write_file(filename, rx_buf, RX_SIZE_IN_BYTE+FRAME_HEAD_IN_BYTE);
		free(rx_buf);
		break;
	}
	default :
		break;
	}

	return NULL;
}

void print_help()
{
	printf("*********************************************\n");
	printf("Usage: timestamp_tcp.exe -strdeh\n");
	printf("-h                print help message\n");
	printf("-t <0 .. 10000>   start RX & TX test\n");
	printf("-s                configure yunsdr\n");
	printf("-e                enable timestamp\n");
	printf("-d                disable timestamp\n");
	printf("-r                read timestamp\n");
	printf("*********************************************\n");
}
