/*
 * ping.c
 *
 *  Created on: 2015��4��2��
 *      Author: Eric
 */


#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

#ifdef WIN32
#include <winsock2.h>
#include <windows.h>
#else
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>
#include <sys/times.h>
#include <errno.h>
typedef struct sockaddr_in SOCKADDR_IN;
typedef struct sockaddr SOCKADDR;
typedef int SOCKET;
#define SOCKET_ERROR -1

uint32_t GetTickCount() 
{
	struct timespec ts;
	unsigned theTick = 0U;
	clock_gettime( CLOCK_REALTIME, &ts );
	theTick  = ts.tv_nsec / 1000000;
	theTick += ts.tv_sec * 1000;
	return theTick;
}
/*
uint32_t getTickCount()
{
    tms tm;
    return times(&tm);
}
*/
#define GetCurrentProcessId getpid
#endif


#define DATA_SIZE 32
#define RECV_MAX_SZIE 1024


typedef struct tag_icmphdr		//icmp frame head
{
	unsigned char	icmp_type;
	unsigned char	icmp_code;
	unsigned short	icmp_checksum;
	unsigned short	icmp_id;
	unsigned short	icmp_sequence;
	unsigned long	icmp_timestamp;
} ICMPHDR, *PICMPHDR;

typedef struct tag_iphdr		//ip frame head
{
	unsigned char	iphVerLen;
	unsigned char	ipTOS;
	unsigned short	ipLength;
	unsigned short	ipID;
	unsigned short	ipFlags;
	unsigned char	ipTTL;
	unsigned char	ipProtacol;
	unsigned short	ipChecksum;
	unsigned long	ipSource;
	unsigned long	ipDestination;
} IPHDR;

unsigned short CheckSum(unsigned short *buf, int size)
{
	unsigned short cksum=0;
	while(size>1)
	{
		cksum+=*buf++;
		size-=sizeof(unsigned short);
	}
	if(size)
		cksum+=*buf++;
	cksum=(cksum>>16)+(cksum&0xffff);
	cksum+=(cksum>>16);
	return (unsigned short)(~cksum);
}

void FillIcmp(PICMPHDR p)
{
	p->icmp_type = 8;
	p->icmp_code = 0;
	p->icmp_checksum = 0;
	p->icmp_id = GetCurrentProcessId();
	p->icmp_sequence = 0;
	p->icmp_timestamp = 0;
}

int ping_proc(char *ip)
{
#ifdef WIN32
	WORD version = MAKEWORD(2,2);
	WSADATA data;
	WSAStartup(version, &data);
	if (LOBYTE(data.wVersion) != 2 || HIBYTE(data.wVersion) != 2)
	{
		printf("WSAStartup failed\n");
		WSACleanup();
		return 0;
	}
#endif
	//char ip[20] = "192.168.1.10";

	SOCKADDR_IN addr;
	addr.sin_family = AF_INET;
#ifdef WIN32
	addr.sin_addr.S_un.S_addr = inet_addr(ip);
#else
	addr.sin_addr.s_addr = inet_addr(ip);
#endif
	addr.sin_port = htons(0);

	SOCKET sock = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);

	int outTime = 1000;
	int rst;
#ifdef WIN32
	rst = setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, (char*)&outTime, sizeof(int));
#else
	struct timeval tv;
	tv.tv_sec = 1;
	tv.tv_usec = 0;
	rst = setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
#endif
	if (SOCKET_ERROR == rst)
	{
		printf("setsockopt erro\n");
		goto err;
	}

#ifdef WIN32
	rst = setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (char*)&outTime, sizeof(int));
#else
	rst = setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
#endif
	if (SOCKET_ERROR == rst)
	{
		printf("setsockopt erro\n");
		goto err;
	}


	char *icmp = (char*)malloc(sizeof(ICMPHDR)+DATA_SIZE);
	memset(icmp, 0, sizeof(ICMPHDR)+DATA_SIZE);
	PICMPHDR picmp = (PICMPHDR)icmp;

	FillIcmp(picmp);

	unsigned short sequence = 0;
	int count = 4;
	char recvbuf[RECV_MAX_SZIE];
	SOCKADDR_IN addrfrom;
	int len = sizeof(SOCKADDR);
	int ipTTL = 0;

	while (count--)
	{
		picmp->icmp_checksum = 0;
		picmp->icmp_timestamp = GetTickCount();
		picmp->icmp_sequence = sequence++;
		picmp->icmp_checksum = CheckSum((unsigned short *)icmp, sizeof(ICMPHDR)+DATA_SIZE);

		int result;
		result = sendto(sock, icmp, sizeof(ICMPHDR)+DATA_SIZE, 0, (SOCKADDR*)&addr, sizeof(SOCKADDR));
		if (SOCKET_ERROR == result)
		{
#ifdef WIN32
			if (WSAETIMEDOUT == WSAGetLastError())
			{
				printf("time out\n");
				continue;
			}
#else
			if(errno){
				printf("recv error:%d, %s\n", errno, strerror(errno));
				continue;
			}
#endif
			else
			{
				printf("sendto error\n");
				goto err;
			}
		}

		result = recvfrom(sock, recvbuf, RECV_MAX_SZIE, 0, (SOCKADDR*)&addrfrom, &len);
		if (SOCKET_ERROR == result)
		{
#ifdef WIN32
			if (WSAETIMEDOUT == GetLastError())
			{
				printf("time out\n");
				continue;
			}
#else
			if(errno){
				printf("recv error:%d, %s\n", errno, strerror(errno));
				continue;
			}
#endif
			else
			{
				printf("recvform error\n");
				goto err;
			}
		}

		int nTick = GetTickCount();
		if (result < sizeof(IPHDR) + sizeof(ICMPHDR) + DATA_SIZE)
		{
			printf("too few bytes\n");
		}

		IPHDR *pIP = (IPHDR*)recvbuf;
		ipTTL = (int)pIP->ipTTL;

		PICMPHDR p = (PICMPHDR)(recvbuf+sizeof(IPHDR));
		if (p->icmp_type != 0)
		{
			printf("error type %d receved\n", p->icmp_type);
			return -1;
		}

		if (p->icmp_id != (unsigned short)GetCurrentProcessId())
		{
			printf("someone else's packet\n");
			return -1;
		}

		printf("reply from: %s", inet_ntoa(addrfrom.sin_addr));
		printf(" data: %d bytes", DATA_SIZE);
		printf(" time: %ld ms", nTick-p->icmp_timestamp);
		printf(" TTL=%d\n", ipTTL);
	}

	return 0;
err:
#ifdef WIN32
	closesocket(sock);
	WSACleanup();
#else
	close(sock);
#endif
	return -1;
}
