/*
 * main.c
 *
 *  Created on: 2015-3-31
 *      Author: Eric
 */

#include "yunsdr_ts.h"

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

extern void *tx_main(void *arg);
extern void *rx_main(void *arg);

int main(int argc, char *argv[])
{
	int ret;
	pthread_t thread_tx, thread_rx;

	ret = pthread_create(&thread_tx, NULL, &tx_main, NULL);
	if (ret)
	{
		dma_dbg(MSG_ERROR, "TX:ERROR, return code from pthread_create() is %d\n", ret);
		return -1;
	}
	ret = pthread_create(&thread_rx, NULL, &rx_main, NULL);
	if (ret)
	{
		dma_dbg(MSG_ERROR, "RX:ERROR, return code from pthread_create() is %d\n", ret);
		return -1;
	}
	pthread_join(thread_tx, NULL);
	pthread_join(thread_rx, NULL);
	return 0;
}
