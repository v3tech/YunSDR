/**
 * $Id: snowleosdr_rx_main.c 2015-1
 *
 * @brief SNOWleo SDR RX main Module.
 *
 * @Author Eric <gaocc@v3best.com>
 *
 * (c) V3best  http://www.zingsoc.com
 *
 * This part of code is written in C programming language.
 * Please visit http://en.wikipedia.org/wiki/C_(programming_language)
 * for more details on the language used herein.
 */
#define _GNU_SOURCE 1
#include "yunsdr_ts.h"

extern uint32_t cur_time;
uint8_t rx_mark = 0;
struct dma_dev s2m_dev;
uint8_t *buf;

/* Function declaration */
static void sig_pipe(int signo);
extern pthread_mutex_t lock;
extern pthread_cond_t cond;

void *rx_main(void *arg)
{
	int ret = 0;
	cpu_set_t mask ;
	CPU_ZERO(&mask);
	CPU_SET(2,&mask);

	ret =pthread_setaffinity_np(pthread_self(),sizeof(mask),(const cpu_set_t*)&mask );
	if(ret < 0)
		dma_dbg(MSG_ERROR,"TX:recv thread:pthread_setaffinity_np error... \n");

	unsigned char *time_base;

	struct global_param rx_param;

	//int nSendBufLen = 256*1024;

	dma_dbg(MSG_DEBUG,"RX:Build: %s  %s\n", __TIME__, __DATE__);

	if (signal(SIGPIPE, sig_pipe) == SIG_ERR)
	{
		dma_dbg(MSG_ERROR,"RX:can't catch SIGPIPE\n");
		return NULL;
	}
	s2m_dev.fd = -1;
	s2m_dev.membase = NULL;
	s2m_dev.mode = M_UNINIT;
	s2m_dev.regbase = NULL;
	s2m_dev.dir = S2MM_CHANNEL;
	if(init_s2m_channel(&s2m_dev) == R_ERROR) {
		return NULL;
	}
	buf = (uint8_t *)malloc(20*1024*1024);
	time_base = init_hw_control();

	/************************adc tcp socket**********************/
	rx_param.sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(rx_param.sockfd == -1)
	{
		dma_dbg(MSG_ERROR,"RX:socket error:%s\n",strerror(errno));
		return NULL;
	}

	bzero(&rx_param.server_addr, sizeof(rx_param.server_addr));
	rx_param.server_addr.sin_family = AF_INET;
	rx_param.server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	rx_param.server_addr.sin_port = htons(5004);
	ret = bind(rx_param.sockfd, (struct sockaddr *)&(rx_param.server_addr), sizeof(rx_param.server_addr));
	if(ret == -1)
	{
		dma_dbg(MSG_ERROR,"RX:bind error:%s\n", strerror(errno));
		return NULL;
	}
	ret = listen(rx_param.sockfd, 1);
	if(ret == -1)
	{
		dma_dbg(MSG_ERROR,"RX:listen error\n");
		return NULL;
	}
	rx_param.client_len = sizeof(struct sockaddr);

	int32_t nbyte;
	rx_param.client_len = sizeof(struct sockaddr_in);
	struct msg_head head;
	while(1){
		rx_param.clifd =accept(rx_param.sockfd, (struct sockaddr *)&(rx_param.client_addr),
				&(rx_param.client_len));
		if(rx_param.clifd == -1)
		{
			dma_dbg(MSG_ERROR,"RX:accept error!\n");
		}else{
			dma_dbg(MSG_DEBUG,"RX:client connect!\n");
		}
		dma_dbg(MSG_DEBUG,"RX:%s %u\n", inet_ntoa(rx_param.client_addr.sin_addr),
				ntohs(rx_param.client_addr.sin_port));

		int nSendBufLen = 10*1024*1024;
		setsockopt(rx_param.clifd, SOL_SOCKET, SO_SNDBUF, (const char *)&nSendBufLen, sizeof(int));
		do{
			nbyte = recv(rx_param.clifd, &head, sizeof(struct msg_head), MSG_WAITALL);
			if(nbyte < 0){
				dma_dbg(MSG_DEBUG,"RX:recv error!\n");
				close(rx_param.clifd);
				break;
			}

			if(nbyte == 0){
				dma_dbg(MSG_DEBUG,"RX:client close!\n");
				close(rx_param.clifd);
				break;
			}

			{
				uint32_t frame_len = 0, rx_len = 0, ch_sel, nbyte;
				uint64_t timestamp;

				ch_sel = (head.control>>16)&0x03;
				if(ch_sel == 0x1 || ch_sel == 0x2)
					frame_len = (head.payload)*4;
				if(ch_sel == 0x3)
					frame_len = (head.payload)*8;
				timestamp = ((uint64_t)(head.param2)<<32)+head.param1;

				rx_len = frame_len + FRAME_HEAD_IN_BYTE;

				if(ch_sel == 0x1 || ch_sel == 0x2) {
					iowrite32(((head.control&(0x1<<8))>>4)|ch_sel, (unsigned long)time_base + RX_CTL);
					iowrite32(frame_len/4, (unsigned long)time_base + RX_LEN);
				}
				if(ch_sel == 0x3) {
					iowrite32(((head.control&(0x1<<8))>>4)|ch_sel, (unsigned long)time_base + RX_CTL);
					iowrite32(frame_len/8, (unsigned long)time_base + RX_LEN);
				}
#if 0
				if((head.control&0xFF) == START_WAIT_TX){
					dma_dbg(MSG_DEBUG,"RX:wait for tx signal!\n");
					pthread_mutex_lock(&lock);
					rx_mark = 1;
					pthread_cond_wait(&cond, &lock);
					pthread_mutex_unlock(&lock);
				}
				//dma_dbg(MSG_DEBUG,"RX:dma start!\n");
				//cur_time = ioread32((unsigned long)time_base + TimetagFromPL);
				//iowrite32(timestamp + cur_time, (unsigned long)time_base + StartTimetag);
#endif

				iowrite32(head.param1, (unsigned long)time_base + RX_TIMESTAMP_L);
				iowrite32(head.param2, (unsigned long)time_base + RX_TIMESTAMP_H);
				dma_dbg(MSG_DEBUG,"RX:rx dma will transfer %d bytes\n", rx_len);
				nbyte = read_samples(&s2m_dev, buf, rx_len, M_NORMAL);
				dma_dbg(MSG_DEBUG,"RX:rx dma transfer %d bytes\n", nbyte);
#if 1
				//if(rx_len < (20*1024*1024))
				//	nbyte = send(rx_param.clifd, (void *)buf, rx_len, 0);
				//else
				nbyte = send(rx_param.clifd, s2m_dev.membase, rx_len, 0);

				if(nbyte < 0){
					// Broken_PIPE=32, client closed
					dma_dbg(MSG_DEBUG,"RX:send:errno=%s\n", strerror(errno));
					continue;
				}
#else
				if(rx_len <= MTU)
					nbyte = send(rx_param.clifd, s2m_dev.membase, rx_len, 0);
				else {
					int count = 0;
					do {
						nbyte = send(rx_param.clifd, s2m_dev.membase+count, rx_len-count, 0);
						if(nbyte >= 0) {
							count += nbyte;
						} else {
							dma_dbg(MSG_DEBUG,"RX:send data failed, close the connection!\n");
							close(rx_param.clifd);
							break;
						}
					}while(count != rx_len);
				}
#endif
				dma_dbg(MSG_DEBUG,"RX:send %d bytes\n", rx_len);
			}

		}while(1);
	}
	return NULL;
}

/**
 * @brief  SIGPIPE handle.to avoid program quit from wrong network connection
 *
 * @param[in]  signo              signal id
 * @retval                        void
 *
 */

static void sig_pipe(int signo)
{
	/*nothing to do*/
}
int save_frame(unsigned char *frame, const char *file_name, int length)
{
	int fd_raw = open(file_name, O_RDWR|O_CREAT| O_APPEND, 0666);

	if(fd_raw < 0)
	{
		dma_dbg(MSG_ERROR,"can not open file\n");
		return -1;
	}

	write(fd_raw, frame, length);
	close(fd_raw);

	return 0;
}
