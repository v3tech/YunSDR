/**
 * $Id: yunsdr_ts.h 2014-5
 *
 * @brief YunSDR sw Module.
 *
 * @Author Eric <gaocc@v3best.com>
 *
 * (c) V3best  http://www.zingsoc.com
 *
 * This part of code is written in C programming language.
 * Please visit http://en.wikipedia.org/wiki/C_(programming_language)
 * for more details on the language used herein.
 */
#ifndef __SW_SET__
#define __SW_SET__
#include <arpa/inet.h>
#include <error.h>
#include <stdint.h>
#include <pthread.h>
#include <yunsdr.h>
#include <signal.h>
#include <linux/ioctl.h>
#include <sys/msg.h>

enum {
	START_TX_NORMAL = 01,
	START_TX_LOOP = 02,
	START_RX_NORMAL = 03,
};

struct msg_head {
	uint32_t control;
	uint32_t param1;
	uint32_t param2;
	uint32_t payload;
};

#define FRAME_HEAD_IN_BYTE 24

#define	TIMESTAMP_CTL	0x10
#define RX_CTL    		0x14
#define RX_LEN    		0x18
#define RX_TIMESTAMP_L	0x1C
#define RX_TIMESTAMP_H	0x20
#define CUR_TIMSTAMP_L  0x24
#define CUR_TIMSTAMP_H	0x28

struct global_param {
	int sockfd;
	int clifd;
	struct sockaddr_in server_addr;
	struct sockaddr_in client_addr;
	socklen_t client_len;
	pthread_t thread_fd;
	pthread_mutex_t mutex_lock;
	pthread_cond_t cond;
};

#define MTU				     1500
#define PACKET_SIZE          1024
#define MaxSize 			 2048
#define BUFFER_MAX_SIZE (PACKET_SIZE*8)
struct ring_buf
{
	unsigned char *data[MaxSize];
	int front,rear;
};

#endif/*__SW_SET__*/
