/**
 * $Id: yunsdr_tx_main.c 2015-1
 *
 * @brief YunSDR TX main Module.
 *
 * @Author Eric <gaocc@v3best.com>
 *
 * (c) V3best  http://www.zingsoc.com
 *
 * This part of code is written in C programming language.
 * Please visit http://en.wikipedia.org/wiki/C_(programming_language)
 * for more details on the language used herein.
 */
#define _GNU_SOURCE 1

#include "yunsdr_ts.h"


#define FRAME_SIZE   ((1024*64)+16)

extern uint8_t rx_mark;
uint32_t cur_time;
unsigned char *tx_mem_addr;
struct dma_dev m2s_dev;
uint8_t *buf;
uint8_t *cb_base;
struct ring_buf *tx_ring;

/**
 * Function declaration
 */
static void sig_pipe(int signo);
void *recv_msg(void *arg);

extern pthread_mutex_t lock;
extern pthread_cond_t cond;

void *tx_main(void *arg)
{
	int ret = 0;
	cpu_set_t mask ;
	CPU_ZERO(&mask);
	CPU_SET(1,&mask);

	ret =pthread_setaffinity_np(pthread_self(),sizeof(mask),(const cpu_set_t*)&mask );
	if(ret < 0)
		dma_dbg(MSG_ERROR,"TX:recv thread:pthread_setaffinity_np error... \n");

	int i;
	pthread_t thread_msg;
	unsigned char *time_base;
	struct global_param tx_param;

	dma_dbg(MSG_DEBUG,"Build: %s  %s\n", __TIME__, __DATE__);

	if (signal(SIGPIPE, sig_pipe) == SIG_ERR)
	{
		dma_dbg(MSG_ERROR, "TX:can't catch SIGPIPE\n");
		return NULL;
	}
	m2s_dev.fd = -1;
	m2s_dev.membase = NULL;
	m2s_dev.mode = M_UNINIT;
	m2s_dev.regbase = NULL;
	m2s_dev.dir = MM2S_CHANNEL;

	if(init_m2s_channel(&m2s_dev) == R_ERROR) {
		dma_dbg(MSG_ERROR, "TX:can't init m2s channel\n");
		exit(1);
	}

	buf = (uint8_t *)malloc(MM2S_BUF_SIZE/2);

	time_base = init_hw_control();

	/* Simple ring buffer */
	cb_base = malloc(20 * 1024 *1024);
	tx_ring = (struct ring_buf *)malloc(sizeof(struct ring_buf));
	tx_ring->front = tx_ring->rear = 0;
		for(i = 0; i < MaxSize; i++)
			tx_ring->data[i] = cb_base + (i * BUFFER_MAX_SIZE);
	/************************tx tcp socket**********************/
	tx_param.sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(tx_param.sockfd == -1)
	{
		dma_dbg(MSG_ERROR,"TX:socket error:%s\n",strerror(errno));
		return NULL;
	}

	bzero(&tx_param.server_addr, sizeof(tx_param.server_addr));
	tx_param.server_addr.sin_family = AF_INET;
	tx_param.server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	tx_param.server_addr.sin_port = htons(5005);
	ret = bind(tx_param.sockfd, (struct sockaddr *)&(tx_param.server_addr), sizeof(tx_param.server_addr));
	if(ret == -1)
	{
		dma_dbg(MSG_ERROR,"TX:bind error:%s\n", strerror(errno));
		return NULL;
	}

	unsigned int len = 0;
	tx_param.client_len = sizeof(struct sockaddr_in);

	ret = listen(tx_param.sockfd, 1);
	if(ret == -1)
	{
		dma_dbg(MSG_ERROR,"TX:listen error\n");
		return NULL;
	}

	//#define CYCLE_MSG
#ifdef CYCLE_MSG
	ret = pthread_create(&thread_msg, NULL, &recv_msg, &tx_param);
	if (ret)
	{
		dma_dbg(MSG_ERROR, "TX:ERROR, return code from pthread_create() is %d\n", ret);
		return NULL;
	}
#else
	tx_param.client_len = sizeof(struct sockaddr);
	do{
		tx_param.clifd =accept(tx_param.sockfd, (struct sockaddr *)&(tx_param.client_addr),
				&(tx_param.client_len));
		if(tx_param.clifd == -1)
		{
			dma_dbg(MSG_ERROR,"TX:accept error\n");
			continue;
		}else{
			dma_dbg(MSG_DEBUG,"TX:client connect!\n");
		}
		int nSendBufLen = 256*1024;
		setsockopt(tx_param.clifd, SOL_SOCKET, SO_SNDBUF, (const char *)&nSendBufLen, sizeof(int));
#endif
		struct msg_head head;
		int32_t nbyte = 0;
		while(1)
		{
#ifndef CYCLE_MSG

			nbyte = recv(tx_param.clifd, &head, sizeof(struct msg_head), MSG_WAITALL);
			if(nbyte < 0){
				dma_dbg(MSG_DEBUG,"TX:recv head error!, %s\n", strerror(errno));
				break;
			}
			if(nbyte == 0){
				dma_dbg(MSG_DEBUG,"TX:client close!\n");
				close(tx_param.clifd);
				break;
			}
			len = head.payload;
			nbyte = recv(tx_param.clifd, buf, head.payload, MSG_WAITALL);
			if(nbyte < 0){
				dma_dbg(MSG_DEBUG,"TX:recv data error!, %s\n", strerror(errno));
				break;
			}
			if(nbyte == 0){
				dma_dbg(MSG_DEBUG,"TX:client close!\n");
				close(tx_param.clifd);
				break;
			}
			dma_dbg(MSG_DEBUG,"TX:len = %d!\n", len);
#else
			if(tx_ring->front==tx_ring->rear)
			{
				//dma_dbg(MSG_WARNING,"cb empty!\n");
				//pthread_mutex_unlock(&lock);
				sleep(0);
				continue;
			}
			else
			{
				memcpy(buf, tx_ring->pdata[tx_ring->front], tx_ring->size[tx_ring->front]);
				len = tx_ring->size[tx_ring->front];
				tx_ring->front=(tx_ring->front+1)%MaxSize;
			}
#endif
			dma_dbg(MSG_DEBUG,"TX:PC expect transmit %d bytes!\n", len);
#if 0
			if(head.control == START_WAIT_RX){
				while(1)
				{
					pthread_mutex_lock(&lock);
					if(rx_mark > 0)
					{
						//cur_time = ioread32((unsigned long)time_base + TimetagFromPL);
						//*((uint32_t *)tx_mem_addr+2) = *((uint32_t *)tx_mem_addr+2) + cur_time;
						pthread_cond_signal(&cond);
						rx_mark = 0;
						pthread_mutex_unlock (&lock);
						break;
					}
					pthread_mutex_unlock(&lock);
				}
			}
#endif

			write_samples(&m2s_dev, buf, len, M_NORMAL);
		}
	}while(1);

	return NULL;
}

void *recv_msg(void *arg)
{
	struct msg_head head;
	uint32_t nbyte;
	struct global_param *tx_param = (struct global_param *)arg;
	int len;
	while(1){
		tx_param->client_len = sizeof(struct sockaddr);
		tx_param->clifd =accept(tx_param->sockfd, (struct sockaddr *)&(tx_param->client_addr),
				&(tx_param->client_len));
		if(tx_param->clifd == -1)
		{
			dma_dbg(MSG_ERROR,"TX:accept error\n");
		}else{
			dma_dbg(MSG_DEBUG,"TX:client connect!\n");
		}
		int nSendBufLen = 256*1024;
		setsockopt(tx_param->clifd, SOL_SOCKET, SO_SNDBUF, (const char *)&nSendBufLen, sizeof(int));
		do {
			if((tx_ring->rear+1)%MaxSize == tx_ring->front)
			{
				//dma_dbg(MSG_WARNING,"cb full!\n");
				//pthread_mutex_unlock(&lock);
				sleep(0);
				continue;
			}
			else
			{
				len = recv(tx_param->clifd, &head, sizeof(struct msg_head), MSG_WAITALL);
				if(len < 0){
					dma_dbg(MSG_DEBUG,"TX:recv error!\n");
					continue;
				}
				if(len == 0){
					dma_dbg(MSG_DEBUG,"TX:client close!\n");
					close(tx_param->clifd);
					break;
				}
				nbyte = head.payload;
				len = recv(tx_param->clifd, tx_ring->data[tx_ring->rear], nbyte, MSG_WAITALL);
				if(len < 0){
					dma_dbg(MSG_DEBUG,"TX:recv error!\n");
					continue;
				}
				if(len == 0){
					dma_dbg(MSG_DEBUG,"TX:client close!\n");
					close(tx_param->clifd);
					break;
				}
				dma_dbg(MSG_DEBUG,"TX:len = %d!\n", len);
				//tx_ring->size[tx_ring->rear] = nbyte;
				tx_ring->rear=(tx_ring->rear+1)%MaxSize;
			}
		}while(1);
	}

	return NULL;
}


/**
 * @brief  SIGPIPE handle to avoid program quit from wrong network connection
 *
 * @param[in]  signo              signal id
 * @retval                        void
 *
 */
static void sig_pipe(int signo)
{
	/*nothing to do*/
}
