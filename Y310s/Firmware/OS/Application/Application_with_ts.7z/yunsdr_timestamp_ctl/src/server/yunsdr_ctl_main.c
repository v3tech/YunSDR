/**
 * $Id: yunsdr_main.c 2014-5
 *
 * @brief YunSDR main Module.
 *
 * @Author jacky <gaocc@v3best.com>
 *
 * (c) V3best  http://www.zingsoc.com
 *
 * This part of code is written in C programming language.
 * Please visit http://en.wikipedia.org/wiki/C_(programming_language)
 * for more details on the language used herein.
 */
#define _GNU_SOURCE 1

#include <signal.h>
#include <arpa/inet.h>
#include <sys/msg.h>
#include "../v3best/yunsdr_hw.h"
#include "../v3best/yunsdr_sw.h"
#include "../v3best/custom_rf_ctl.h"
#include "../ad9361-hw/console_commands/command.h"


#define	TIMESTAMP_CTL	0x10
#define RX_CTL    		0x14
#define RX_LEN    		0x18
#define RX_TIMESTAMP_L	0x1C
#define RX_TIMESTAMP_H	0x20
#define CUR_TIMSTAMP_L  0x24
#define CUR_TIMSTAMP_H	0x28

extern custom_command	  	custom_cmd_list[];
extern command	  	cmd_list[];
double		 sdr_param[5]		 = {0, 0, 0, 0, 0};
char			sdr_param_no		 =  0;

#define  LENGTH_MIN           8
#define  LENGTH_MAX           4088

/**/
#define  PACKAGE_HEAD         0xF0
#define  SDR_HANDSHAKE        0x16
#define  SDR_HANDSHAKE2       0x17
#define  SDR_TX_CHANNEL_SEL   0x20
#define  SDR_RX_CHANNEL_SEL   0x21
#define  SDR_CUSTOM_CMD       0x22
#define  SDR_READ_TIME        0x23


/**/
enum {
	E_TX,
	E_RX,
};

enum {
	SDR_DEVICE_Y300 = 300,
	SDR_DEVICE_Y310 = 310,
};

unsigned int device_type;
struct global_param cmd_param;
unsigned int cmd_buff[2];
pthread_t thread_cmd;
unsigned char *reg_base;
//unsigned char *dma_reg_addr_rd;


/**
 * Function declaration
 */
void *thread_cmd_func(void *arg);
static void sig_pipe(int signo);
int send_msg(long int msg_type, unsigned int param);
extern int ad_9361_main(uint32_t device_type);

int main (int argc, char *argv[])
{

	int ret;

	dma_dbg(MSG_DEBUG,"CMD:Build: %s  %s\n", __TIME__, __DATE__);

	if (signal(SIGPIPE, sig_pipe) == SIG_ERR)
	{
		dma_dbg(MSG_ERROR,"CMD:can't catch SIGPIPE\n");
		exit(1);
	}

	/**
	 * Memory Mapping
	 */

	reg_base = map_memory(AXI_DMA_BASE_WR, REG_SIZE);
	//device_type = ioread32((unsigned long)reg_base + 0x18);
	device_type = SDR_DEVICE_Y310;
	if(device_type == SDR_DEVICE_Y300){
		dma_dbg(MSG_DEBUG,"CMD:DEVICE TYPE: Y300.\n");
	}else if(device_type == SDR_DEVICE_Y310){
		dma_dbg(MSG_DEBUG,"CMD:DEVICE TYPE: Y310.\n");
	}else{
		dma_dbg(MSG_DEBUG,"CMD:DEVICE TYPE: Unknown device.\n");
		device_type = SDR_DEVICE_Y310;
	}

	/* ad9361 init */
	ad9361_main(device_type);
	if(device_type == SDR_DEVICE_Y310){
		custom_rf_ctl_init();
		adf4001_spi_setup();
	}
	/*******************cmd udp socket**************************/
	// Init socket
	cmd_param.server_addr.sin_family=AF_INET;
	cmd_param.server_addr.sin_port = htons(5006);
	cmd_param.server_addr.sin_addr.s_addr = htonl(INADDR_ANY);

	cmd_param.sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if(cmd_param.sockfd < 0){
		dma_dbg(MSG_ERROR,"CMD:ERROR,create socket failed\n");
	}

	if(bind(cmd_param.sockfd, (struct sockaddr *)&(cmd_param.server_addr), sizeof(cmd_param.server_addr)) < 0)
		perror("bind");
	/************************************************************/
	cmd_param.client_len = sizeof(struct sockaddr_in);
	while(1)
	{
		recvfrom(cmd_param.sockfd, (void *)cmd_buff, sizeof(unsigned int)*2,
				0, (struct sockaddr*)&(cmd_param.client_addr), &(cmd_param.client_len));

		dma_dbg(MSG_DEBUG,"CMD:cmd[0] = 0x%x, cmd[1] = 0x%x\n", cmd_buff[0], cmd_buff[1]);
		if((cmd_buff[0]&0xFF000000)>>24!= PACKAGE_HEAD)
		{
			memset((unsigned char *)cmd_buff, 0, sizeof(unsigned int)*2);
			perror("package error!\n");
			continue;
		}

		switch ((cmd_buff[0]&0x00FF0000)>>16)
		{
		case SDR_CUSTOM_CMD:
		{
			unsigned char cmd = (cmd_buff[0]&0x0000FF00)>>8;
			if(cmd >= 0 && cmd < 30) {
				if(cmd == 3 || cmd == 15){
					sdr_param[0] = (uint64_t)cmd_buff[1]|(((uint64_t)cmd_buff[0]&0x000000FF)<<32);
					printf("freq = %llu\n", (uint64_t)sdr_param[0]);
				}else{
					sdr_param[0] = cmd_buff[1];
				}

				sdr_param_no = 1;
				cmd_list[cmd].function(sdr_param, sdr_param_no);
				if(device_type == SDR_DEVICE_Y310){
					if(cmd == 3){
						tx_band_sel((uint64_t)sdr_param[0]);
						tx_rf_port_input_select((uint64_t)sdr_param[0]);
					}
					if(cmd == 15){
						rx1_band_sel((uint64_t)sdr_param[0]);
						rx2_band_sel((uint64_t)sdr_param[0]);
						rx_rf_port_input_select((uint64_t)sdr_param[0]);
					}
				}
			}
			else if(cmd >= 40 && cmd <= 45) {
				if(device_type == SDR_DEVICE_Y310){
					custom_cmd_list[cmd-40].function(cmd_buff[1]);
				}
			}
			else
				dma_dbg(MSG_WARNING,"CMD:undefined command!\n");
			dma_dbg(MSG_DEBUG,"CMD:recv SDR_CUSTOM cmd\n");
			break;
		}
		case SDR_READ_TIME:
		{
			if(cmd_buff[1] == 1)
				iowrite32(0x1, (unsigned long)reg_base + TIMESTAMP_CTL);
			else if(cmd_buff[1] == 2)
				iowrite32(0x0, (unsigned long)reg_base + TIMESTAMP_CTL);
			else{
				cmd_buff[0] = ioread32((unsigned long)reg_base + CUR_TIMSTAMP_L);
				cmd_buff[1] = ioread32((unsigned long)reg_base + CUR_TIMSTAMP_H);
				sendto(cmd_param.sockfd, (void *)cmd_buff, sizeof(unsigned int)*2,
						0, (struct sockaddr*)&(cmd_param.client_addr), sizeof(cmd_param.client_addr));
			}
			dma_dbg(MSG_DEBUG,"CMD:recv SDR_CUSTOM cmd\n");
			break;
		}
		default:
			break;
		}

		memset((unsigned char *)cmd_buff, 0, sizeof(unsigned int)*2);
	}

	return 0;
}

/**
 * @brief  SIGPIPE handle.to avoid program quit from wrong network connection
 *
 * @param[in]  signo              signal id
 * @retval                        void
 *
 */
static void sig_pipe(int signo)
{
	/*nothing to do*/
}
int send_msg(long int msg_type, unsigned int param)
{
	struct msg_st data;
	int msgid = -1;


	msgid = msgget((key_t)1234, 0666 | IPC_CREAT);
	if(msgid == -1)
	{
		dma_dbg(MSG_ERROR, "CMD:msgget failed with error: %d\n", errno);
		return -1;
	}
	data.msg_type = msg_type;
	data.param = param;

	if(msgsnd(msgid, (void*)&data, sizeof(struct msg_st), 0) == -1)
	{
		dma_dbg(MSG_ERROR, "CMD:msgsnd failed\n");
		return -1;
	}
	return 0;
}
