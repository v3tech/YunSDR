/**
 * $Id: snowleo_hw.h 2014-5
 *
 * @brief SNOWleo SDR hw Module.
 *
 * @Author Eric <gaocc@v3best.com>
 *
 * (c) V3best  http://www.zingsoc.com
 *
 * This part of code is written in C programming language.
 * Please visit http://en.wikipedia.org/wiki/C_(programming_language)
 * for more details on the language used herein.
 */
#ifndef __HW_SET__
#define __HW_SET__
#include <stdio.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>

/*AXI DMA IPcore memory map address*/
#define AXI_DMA_BASE_WR 0x41210000
#define AXI_DMA_BASE_RD 0x41220000

/*AXI DMA IPcore register offset*/
#define MM2S_HW
#ifdef MM2S_HW
#define MM2S_START   0x0
#define MM2S_SA      0x4
#define MM2S_LENGTH  0x8
#define MM2S_CYC     0xc

#define MM2S_DONE     0x0
#endif

#define S2MM_START   0x0
#define S2MM_DA      0x4
#define S2MM_LENGTH  0x8
#define S2MM_CYC     0xc

/*AXI DMA IPcore mask*/
#define S2MM_DONE   0x0

#define S2MM_CHANNEL  0
#define MM2S_CHANNEL  1

#define IP_RESET  	 0
#define FIFO_IP_RESET	 1

#if 0
/*DDR phy address for AXI DMA IPcore*/
#define ZING_MINI_SOM
//#define LARGE_DATA
//#define WX200_7010_256M
#if defined(ZING_MINI_SOM) && !defined(LARGE_DATA)
#define  S2MM_DST_ADDR 0x1C000000
#define  MM2S_SRC_ADDR 0x18000000
#elif defined(ZING_MINI_SOM) && defined(LARGE_DATA)
#define  MM2S_SRC_ADDR 0x1F000000
#define  S2MM_DST_ADDR 0x10000000
#elif defined(WX200_7010_256M)
#define  S2MM_DST_ADDR 0xD000000
#define  MM2S_SRC_ADDR 0xE800000
#elif defined(ZING_DDR_1G)
#define  S2MM_DST_ADDR 0x30000000
#define  MM2S_SRC_ADDR 0x38000000
#endif
#endif

#define  S2MM_BUF_SIZE (240*1024*1024)
#define  MM2S_BUF_SIZE (8*1024*1024)

#define  REG_SIZE        4096

/**
 * @brief Write 32bit value to Specified Virtual DDR address.
 *
 * @param[in] val            The value to be written
 * @param[in] addr           The Virtual DDR address to be written
 *
 */
inline void iowrite32(unsigned long val, unsigned long addr);

/**
 * @brief Read 32bit value from Specified Virtual DDR address.
 *
 * @param[in] addr          The Virtual DDR address to be read
 * @retval                  the value from addr
 *
 */
inline unsigned long ioread32(unsigned long addr);

/**
 * @brief start AXI dma IPcore.
 *
 * @param[in] channel          0 S2MM_CHANNEL, 1 MM2S_CHANNEL
 * @param[in] mode             Operating Mode of MM2S_CHANNEL  0 Auto, 1 Manual
 * @param[in] reg_baseaddr     Virtual register address of AXI dma IPcore
 * @retval                     0 Success
 * @retval                     -1 Failure
 *
 */
inline int axi_dma_start(int channel, int mode, unsigned long reg_baseaddr);

/**
 * @brief Setup AXI dma IPcore.
 *
 * @param[in] channel          0 S2MM_CHANNEL, 1 MM2S_CHANNEL
 * @param[in] length           Data length for once dma transmission
 * @param[in] cycle            Number of dma transmission
 * @param[in] mem_addr         Physical DDR address of AXI dma IPCore
 * @param[in] reg_baseaddr     Virtual register address of AXI dma IPcore
 * @retval                     0 Success
 * @retval                     -1 Failure
 *
 */
inline int axi_dma_init(int channel, unsigned long length, unsigned int cycle,
		unsigned long mem_addr, unsigned long reg_baseaddr);

/**
 * @brief Detect transmission is completed.
 *
 * @param[in] channel          0 S2MM_CHANNEL, 1 MM2S_CHANNEL
 * @param[in] reg_baseaddr     Virtual register address of AXI dma IPcore
 * @retval                     0 Success
 * @retval                     -1 Failure
 *
 */
inline int check_dma_done(int channel, unsigned long reg_baseaddr);

/**
 * @brief reset AXI dma IPcore.
 *
 * @param[in] channel          0 S2MM_CHANNEL, 1 MM2S_CHANNEL
 * @param[in] length           Data length for once dma transmission
 * @param[in] reg_baseaddr     Virtual register address of AXI dma IPcore
 * @param[in] type             reset type, IP_RESET only reset IPCore, FIFO_IP_RESET reset IPcore&fifo
 * @retval                     0 Success
 * @retval                     -1 Failure
 *
 */
inline int axi_dma_reset(int channel, unsigned long reg_baseaddr, int type);

/**
 * @brief  map the specified physical address to the virtual address.
 *
 * @param[in] startAddress     The physical DDR address to be mapped
 * @param[in] size             memory size to be mapped
 * @retval                     The Virtual DDR address
 *
 */
void *map_memory(unsigned long startAddress, unsigned long size);

/**
 * @brief unmap the specified virtual address.
 *
 * @param[in] startAddress     The virtual DDR address to be unmapped
 * @param[in] size             memory size to be unmapped
 *
 */
void unmap_memory(unsigned char *virtual_addr, unsigned long size);

#define DEBUG  4
enum {
	MSG_ERROR = 0,
	MSG_WARNING = 1,
	MSG_NOTICE,
	MSG_DEBUG,
};


#ifdef  DEBUG
#define dma_dbg(level,fmt,args...) if (DEBUG>=level) printf(fmt,##args);
#else
#define dma_dbg(level,fmt,args...)
#endif  /* DEBUG */

struct axi_dma_config_info {
	int channel;
	unsigned long mem_addr;
	unsigned long length;
	unsigned int reset_type;
};
#define  XDMA_MAGIC              'D'
#define  XDMA_IOCTL_RESET                _IO(XDMA_MAGIC, 1)
#define  XDMA_START_WAIT_COMPLETE        _IO(XDMA_MAGIC, 2)
#define  XDMA_IOCTL_CONFIG               _IO(XDMA_MAGIC, 3)
#define  XDMA_MEM_ALLOC                  _IO(XDMA_MAGIC, 4)
#define  LENGTH_MIN           8
#define  LENGTH_MAX           4088

enum {
	R_NORMAL = 0,
	R_ERROR = -1,
	R_UNKNOWN = -2,
};
enum {
	M_NORMAL = 0,
	M_LOOPBACK = 1,
	M_UNINIT = 2,
};
#if 0
/**
 * @brief  The struct describe adc&dac channel.
 *
 */
struct dma_dev {
	int fd;
	uint8_t *regbase;
	uint8_t *membase;
	uint32_t phybase;
	uint8_t mode;
	uint8_t dir;
};

/**
 * @brief  map hw control reg.
 *
 * @param                      None
 * @retval                     The regbase Virtual DDR address
 *
 */
uint8_t *init_hw_control(void);

/**
 * @brief  reset dac dma channel when it works on loopback mode.
 *
 * @param[in] dev              The struct describe adc&dac channel
 * @retval                     0:Normal return; -1:error
 *
 */
int hw_reset(struct dma_dev *dev);

/**
 * @brief  init dac dma channel, map regbase and membase.
 *
 * @param[out] s2m_dev         The struct describe dac channel
 * @retval                     0:Normal return; -1:error
 *
 */
int init_s2m_channel(struct dma_dev *s2m_dev);

/**
 * @brief  init adc dma channel, map regbase and membase.
 *
 * @param[out] m2s_dev         The struct describe adc channel
 * @retval                     0:Normal return; -1:error
 *
 */
int init_m2s_channel(struct dma_dev *m2s_dev);

/**
 * @brief  release adc dma channel, unmap regbase and membase.
 *
 * @param[out] s2m_dev         The struct describe adc channel
 * @retval                     0:Normal return; -1:error
 *
 */
int deinit_s2m_channel(struct dma_dev *s2m_dev);

/**
 * @brief  release dac dma channel, unmap regbase and membase.
 *
 * @param[out] m2s_dev         The struct describe dac channel
 * @retval                     0:Normal return; -1:error
 *
 */
int deinit_m2s_channel(struct dma_dev *m2s_dev);

/**
 * @brief  read up to size bytes via adc dma channel into the buffer starting at buf.
 *
 * @param[in]  s2m_dev     	    The struct describe adc channel
 * @param[out] buf              cache the samples
 * @param[in]  size             size samples to be read
 * @param[in]  mode             not used
 * @retval                      On success,The number of bytes read; On error, -1 is returned
 *
 */
int read_samples(struct dma_dev *s2m_dev, uint8_t *buf, uint32_t size, uint8_t mode);

/**
 * @brief  write up to size bytes from the buffer pointed buf via dac dma channel.
 *
 * @param[in]  m2s_dev     	    The struct describe dac channel
 * @param[out] buf              cache the samples
 * @param[in]  size             size samples to be written
 * @param[in]  mode             dma mode(normal;loopback)
 * @retval                      On success,The number of bytes written; On error, -1 is returned
 *
 */
int write_samples(struct dma_dev *m2s_dev, uint8_t *buf, uint32_t size, uint8_t mode);
#endif

#endif/*__HW_SET__*/
