/**
 * $Id: snowleo_hw.c 2014-5
 *
 * @brief SNOWleo SDR main Module.
 *
 * @Author jacky <gaocc@v3best.com>
 *
 * (c) V3best  http://www.zingsoc.com
 *
 * This part of code is written in C programming language.
 * Please visit http://en.wikipedia.org/wiki/C_(programming_language)
 * for more details on the language used herein.
 */
#include <stdio.h>
#include "yunsdr_hw.h"
#include "../yunsdr.h"

/**
 * @brief Setup AXI dma IPcore.
 *
 * @param[in] channel          0 S2MM_CHANNEL, 1 MM2S_CHANNEL
 * @param[in] length           Data length for once dma transmission
 * @param[in] cycle            Number of dma transmission 
 * @param[in] mem_addr         Physical DDR address of AXI dma IPCore
 * @param[in] reg_baseaddr     Virtual register address of AXI dma IPcore
 * @retval                     0 Success
 * @retval                     -1 Failure
 *
 */
inline int axi_dma_init(int channel, unsigned long length, unsigned int cycle,
		unsigned long mem_addr, unsigned long reg_baseaddr)
{
	if(channel == 0) {
		iowrite32(mem_addr, reg_baseaddr + S2MM_DA);
		iowrite32(length, reg_baseaddr + S2MM_LENGTH);
		iowrite32(cycle, reg_baseaddr + S2MM_CYC);
	}

	if(channel == 1) {
		iowrite32(mem_addr, reg_baseaddr + MM2S_SA);
		iowrite32(length, reg_baseaddr + MM2S_LENGTH);
		iowrite32(cycle, reg_baseaddr + MM2S_CYC);
	}

	return 0;
}


/**
 * @brief start AXI dma IPcore.
 *
 * @param[in] channel          0 S2MM_CHANNEL, 1 MM2S_CHANNEL
 * @param[in] mode             Operating Mode of MM2S_CHANNEL  0 Auto, 1 Manual
 * @param[in] reg_baseaddr     Virtual register address of AXI dma IPcore
 * @retval                     0 Success
 * @retval                     -1 Failure
 *
 */
inline int axi_dma_start(int channel, int mode, unsigned long reg_baseaddr)
{
	if(channel == 0)
		iowrite32(0x11, reg_baseaddr + S2MM_START);

	if(channel == 1) {
		if(mode == 1)
			iowrite32(0x11, reg_baseaddr + MM2S_START);
		else
			iowrite32(0x13, reg_baseaddr + MM2S_START);
	}

	return 0;
}

/**
 * @brief reset AXI dma IPcore.
 *
 * @param[in] channel          0 S2MM_CHANNEL, 1 MM2S_CHANNEL
 * @param[in] length           Data length for once dma transmission
 * @param[in] reg_baseaddr     Virtual register address of AXI dma IPcore
 * @param[in] type             reset type, IP_RESET only reset IPCore, FIFO_IP_RESET reset IPcore&fifo
 * @retval                     0 Success
 * @retval                     -1 Failure
 *
 */
inline int axi_dma_reset(int channel, unsigned long reg_baseaddr, int type)
{
	if(channel == 0&&type == IP_RESET)
		iowrite32(0x10, reg_baseaddr + S2MM_START);
	if(channel == 1&&type == IP_RESET)
		iowrite32(0x10, reg_baseaddr + MM2S_START);

	if(channel == 0&&type == FIFO_IP_RESET)
		iowrite32(0x00, reg_baseaddr + S2MM_START);
	if(channel == 1&&type == FIFO_IP_RESET)
		iowrite32(0x00, reg_baseaddr + MM2S_START);

	return 0;
}

/**
 * @brief Write 32bit value to Specified Virtual DDR address.
 *
 * @param[in] val            The value to be written
 * @param[in] addr           The Virtual DDR address to be written
 *
 */
inline void iowrite32(unsigned long val, unsigned long addr)
{
	*(unsigned long *)addr = val;
}

/**
 * @brief Read 32bit value from Specified Virtual DDR address.
 *
 * @param[in] addr          The Virtual DDR address to be read
 * @retval                  the value from addr
 *
 */
inline unsigned long ioread32(unsigned long addr)
{
	return *(unsigned long *)addr;
}

/**
 * @brief  map the specified physical address to the virtual address.
 *
 * @param[in] startAddress     The physical DDR address to be mapped
 * @param[in] size             memory size to be mapped
 * @retval                     The Virtual DDR address
 *
 */
void *map_memory(unsigned long startAddress, unsigned long size)
{
	int fd = open( "/dev/mem", O_RDWR);
	void * *virtual_addr;

	virtual_addr = (void *)mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED,
			fd, (off_t)startAddress);

	close (fd);

	return virtual_addr;
}

/**
 * @brief unmap the specified virtual address.
 *
 * @param[in] startAddress     The virtual DDR address to be unmapped
 * @param[in] size             memory size to be unmapped
 *
 */
void unmap_memory(unsigned char *virtual_addr, unsigned long size)
{
	int fd = open( "/dev/mem", O_RDWR);

	munmap((void *)virtual_addr, size);
	close (fd);
}

uint8_t *init_hw_control(void)
{
	/**
	 * Memory Mapping
	 */
	uint8_t *regbase = NULL;
	void *page_ptr;
	long page_addr, page_off, page_size = sysconf(_SC_PAGESIZE);

	page_addr = AXI_DMA_BASE_WR & (~(page_size-1));
	page_off  = AXI_DMA_BASE_WR - page_addr;

	page_ptr = map_memory(page_addr, REG_SIZE);
	if(page_ptr == MAP_FAILED) {
		printf("memory mmap failed!\n");
		return NULL;
	}


	regbase = page_ptr + page_off;

	return regbase;

}


int init_s2m_channel(struct dma_dev *s2m_dev)
{
	struct axi_dma_config_info config_info;

	s2m_dev->fd = open ("/dev/v3best-dma-wr", O_RDWR, 0);
	if (s2m_dev->fd < 0) {
		perror("open");
		return R_ERROR;
	}
	dma_dbg(MSG_DEBUG,"RX:/dev/v3best-dma-wr opened, fd=%d\n", s2m_dev->fd);

	/**
	 * Memory Mapping
	 */
	config_info.channel = S2MM_CHANNEL;
	config_info.length = S2MM_BUF_SIZE;

	if(ioctl(s2m_dev->fd, XDMA_MEM_ALLOC, &config_info) < 0)
	{
		perror("ioctl");
		close(s2m_dev->fd);
		return R_ERROR;
	}
	printf("phy_base = 0x%lx\n",config_info.mem_addr);
	s2m_dev->membase = mmap(0, config_info.length, PROT_READ|PROT_WRITE, MAP_SHARED, s2m_dev->fd, 0);

	if(s2m_dev->membase == MAP_FAILED) {
		s2m_dev->membase = 0;
		close(s2m_dev->fd);
		return R_ERROR;
	}
	s2m_dev->phybase = config_info.mem_addr;
	printf("mem_base:0x%x,len:0x%lx\n",(unsigned int)s2m_dev->membase, config_info.length);

	s2m_dev->regbase = map_memory(AXI_DMA_BASE_WR, REG_SIZE);
	if(s2m_dev->regbase == MAP_FAILED) {
		printf("memory mmap failed!\n");
		close(s2m_dev->fd);
		munmap(s2m_dev->membase, S2MM_BUF_SIZE);
		return R_ERROR;
	}

	return R_NORMAL;

}

int init_m2s_channel(struct dma_dev *m2s_dev)
{
	struct axi_dma_config_info config_info;

	m2s_dev->fd = open ("/dev/v3best-dma-rd", O_RDWR, 0);
	if (m2s_dev->fd < 0) {
		perror("TX:open");
		return R_ERROR;
	}
	dma_dbg(MSG_DEBUG,"TX:/dev/v3best-dma-rd opened, fd=%d\n", m2s_dev->fd);

	/**
	 * Memory Mapping
	 */
	config_info.channel = MM2S_CHANNEL;
	config_info.length = MM2S_BUF_SIZE;

	if(ioctl(m2s_dev->fd, XDMA_MEM_ALLOC, &config_info) < 0)
	{
		perror("ioctl");
		close(m2s_dev->fd);
		return R_ERROR;
	}
	printf("phy_base = 0x%lx\n",config_info.mem_addr);
	m2s_dev->membase = mmap(0, config_info.length, PROT_READ|PROT_WRITE, MAP_SHARED, m2s_dev->fd, 0);

	if(m2s_dev->membase == MAP_FAILED) {
		m2s_dev->membase = 0;
		close(m2s_dev->fd);
		return R_ERROR;
	}
	m2s_dev->phybase = config_info.mem_addr;
	printf("mem_base:0x%x,len:0x%lx\n",(unsigned int)m2s_dev->membase, config_info.length);

	m2s_dev->regbase = map_memory(AXI_DMA_BASE_RD, REG_SIZE);
	if(m2s_dev->regbase == MAP_FAILED) {
		dma_dbg(MSG_ERROR,"TX:memmap failed: %s\n", strerror(errno));
		close(m2s_dev->fd);
		munmap(m2s_dev->membase, MM2S_BUF_SIZE);
		return R_ERROR;
	}

	return R_NORMAL;
}
int deinit_s2m_channel(struct dma_dev *s2m_dev)
{
	int32_t ret = R_NORMAL;

	munmap(s2m_dev->membase, S2MM_BUF_SIZE);
	close(s2m_dev->fd);
	unmap_memory(s2m_dev->regbase, REG_SIZE);
	s2m_dev->fd = -1;
	s2m_dev->membase = NULL;
	s2m_dev->mode = M_UNINIT;
	s2m_dev->regbase = NULL;

	return ret;

}

int deinit_m2s_channel(struct dma_dev *m2s_dev)
{
	int32_t ret = R_NORMAL;

	munmap(m2s_dev->membase, MM2S_BUF_SIZE);
	close(m2s_dev->fd);
	unmap_memory(m2s_dev->regbase, REG_SIZE);
	m2s_dev->fd = -1;
	m2s_dev->membase = NULL;
	m2s_dev->mode = M_UNINIT;
	m2s_dev->regbase = NULL;

	return ret;
}

int hw_reset(struct dma_dev *dev)
{
	int32_t ret = R_NORMAL;

	struct axi_dma_config_info config_info;
	config_info.channel = dev->dir;
	if(dev->mode == M_LOOPBACK && dev->dir == MM2S_CHANNEL) {
		if(ioctl(dev->fd, XDMA_START_WAIT_COMPLETE, &config_info) < 0)
		{
			perror("ioctl-wait");
		}
	}
	axi_dma_reset(dev->dir, (unsigned long)(dev->regbase), FIFO_IP_RESET);

	return ret;
}
#if 0
int read_samples(struct dma_dev *s2m_dev, uint8_t *buf, uint32_t size, uint8_t mode)
{
	struct axi_dma_config_info config_info;
	config_info.channel = S2MM_CHANNEL;

	int i;
	unsigned int length = 0, times = 0;

	if(size > S2MM_BUF_SIZE || size%8 != 0){
		return R_ERROR;
	}

	if(size <= LENGTH_MAX){
		length = size;
		times = 1;
		dma_dbg(MSG_DEBUG,"RX:rx_length = %d, length = %d, times = %d\n", size, length, times);
	} else {
		for(i = LENGTH_MAX; i>=8; i-=8) {
			if(size%i==0) {
				length = i;
				times = size/i;
				dma_dbg(MSG_DEBUG,"RX:rx_length = %d, length = %d, times = %d\n", size, length, times);
				break;
			}
		}
	}

	axi_dma_init(S2MM_CHANNEL, length, times-1, s2m_dev->phybase,
			(unsigned long)(s2m_dev->regbase));
	if(ioctl(s2m_dev->fd, XDMA_START_WAIT_COMPLETE, &config_info) < 0)
	{
		perror("ioctl-wait");
	}
	if(mode == M_LOOPBACK) {
		axi_dma_reset(S2MM_CHANNEL, (unsigned long)(s2m_dev->regbase), FIFO_IP_RESET);
		//dma_dbg(MSG_DEBUG,"adc dma fifo&ip reset");
	} else {
		axi_dma_reset(S2MM_CHANNEL, (unsigned long)(s2m_dev->regbase), IP_RESET);
		//dma_dbg(MSG_DEBUG,"adc dma ip reset");
	}

	if(size < (20*1024*1024))
		memcpy(buf, s2m_dev->membase, size);

	return size;
}
#else
int read_samples(struct dma_dev *s2m_dev, uint8_t *buf, uint32_t size, uint8_t mode)
{
	struct axi_dma_config_info config_info;
	config_info.channel = S2MM_CHANNEL;

	unsigned int length = 0, times = 0, sum = 0, ret;

	if(size > S2MM_BUF_SIZE || size%8 != 0){
		return R_ERROR;
	}
	ret = ioread32((unsigned long)(s2m_dev->regbase) + 0x14)&(~(0x1<<8));
	iowrite32(ret | (0x1<<8), (unsigned long)(s2m_dev->regbase) + 0x14);
	if(size <= LENGTH_MAX){
		length = size;
		times = 1;
		dma_dbg(MSG_DEBUG,"RX:rx_length = %d, length = %d, times = %d\n", size, length, times);
		axi_dma_init(S2MM_CHANNEL, length, times-1, s2m_dev->phybase,
				(unsigned long)(s2m_dev->regbase));
		if(ioctl(s2m_dev->fd, XDMA_START_WAIT_COMPLETE, &config_info) < 0)
		{
			perror("ioctl-wait");
		}
		if(mode == M_LOOPBACK) {
			axi_dma_reset(S2MM_CHANNEL, (unsigned long)(s2m_dev->regbase), FIFO_IP_RESET);
			//dma_dbg(MSG_DEBUG,"adc dma fifo&ip reset");
		} else {
			axi_dma_reset(S2MM_CHANNEL, (unsigned long)(s2m_dev->regbase), IP_RESET);
			//dma_dbg(MSG_DEBUG,"adc dma ip reset");
		}
	} else {
		length = 4000;
		times = size/4000;
		sum = length * times;
		dma_dbg(MSG_DEBUG,"RX:rx_length = %d, length = %d, times = %d\n", size, length, times);
		axi_dma_init(S2MM_CHANNEL, length, times-1, s2m_dev->phybase,
				(unsigned long)(s2m_dev->regbase));
		if(ioctl(s2m_dev->fd, XDMA_START_WAIT_COMPLETE, &config_info) < 0)
		{
			perror("ioctl-wait");
		}
		axi_dma_reset(S2MM_CHANNEL, (unsigned long)(s2m_dev->regbase), IP_RESET);

		if(size%4000 != 0) {
			length = size%4000;
			times = 1;
			dma_dbg(MSG_DEBUG,"RX:rx_length = %d, length = %d, times = %d\n", size, length, times);
			axi_dma_init(S2MM_CHANNEL, length, times-1, s2m_dev->phybase+sum,
					(unsigned long)(s2m_dev->regbase));
			if(ioctl(s2m_dev->fd, XDMA_START_WAIT_COMPLETE, &config_info) < 0)
			{
				perror("ioctl-wait");
			}
		}
		if(mode == M_LOOPBACK) {
			axi_dma_reset(S2MM_CHANNEL, (unsigned long)(s2m_dev->regbase), FIFO_IP_RESET);
			//dma_dbg(MSG_DEBUG,"adc dma fifo&ip reset");
		} else {
			axi_dma_reset(S2MM_CHANNEL, (unsigned long)(s2m_dev->regbase), IP_RESET);
			//dma_dbg(MSG_DEBUG,"adc dma ip reset");
		}

	}
	ret = ioread32((unsigned long)(s2m_dev->regbase) + 0x14)&(~(0x1<<8));
	iowrite32(ret, (unsigned long)(s2m_dev->regbase) + 0x14);
	//if(size < (20*1024*1024))
	//	memcpy(buf, s2m_dev->membase, size);

	return size;
}
#endif
#if 0
int write_samples(struct dma_dev *m2s_dev, uint8_t *buf, uint32_t size, uint8_t mode)
{
	uint32_t length = 0, times = 0, i;
	struct axi_dma_config_info config_info;
	config_info.channel = MM2S_CHANNEL;

	if(size > MM2S_BUF_SIZE || size%8!=0)
		return R_ERROR;

	if(m2s_dev->mode == M_LOOPBACK){
		if(ioctl(m2s_dev->fd, XDMA_START_WAIT_COMPLETE, &config_info) < 0)
		{
			perror("ioctl-wait");
		}
		axi_dma_reset(MM2S_CHANNEL, (unsigned long)(m2s_dev->regbase), FIFO_IP_RESET);
	}

	memcpy(m2s_dev->membase, buf, size);

	if(size <= LENGTH_MAX){
		length = size;
		times = 1;
		//dma_dbg(MSG_DEBUG,"TX:file_length = %d, length = %d, times = %d\n", size, length, times);
	} else {
		for(i = LENGTH_MAX; i>=8; i-=8) {
			if(size%i==0) {
				length = i;
				times = size/i;
				//dma_dbg(MSG_DEBUG,"TX:file_length = %d, length = %d, times = %d\n", size, length, times);
				break;
			}
		}
	}
	axi_dma_init(MM2S_CHANNEL, length, times-1, (unsigned long)m2s_dev->phybase,
			(unsigned long)(m2s_dev->regbase));
	if(mode == M_LOOPBACK){
		axi_dma_start(MM2S_CHANNEL, 0, (unsigned long)(unsigned long)(m2s_dev->regbase));
		m2s_dev->mode = M_LOOPBACK;
	} else {
		if(ioctl(m2s_dev->fd, XDMA_START_WAIT_COMPLETE, &config_info) < 0)
		{
			perror("ioctl-wait");
		}
		axi_dma_reset(MM2S_CHANNEL, (unsigned long)(unsigned long)(m2s_dev->regbase), IP_RESET);
		m2s_dev->mode = M_NORMAL;
	}

	return size;
}
#else
int write_samples(struct dma_dev *m2s_dev, uint8_t *buf, uint32_t size, uint8_t mode)
{
	uint32_t length = 0, times = 0, sum = 0;
	struct axi_dma_config_info config_info;
	config_info.channel = MM2S_CHANNEL;

	if(size > MM2S_BUF_SIZE || size%8!=0)
		return R_ERROR;

	memcpy(m2s_dev->membase, buf, size);

	if(size <= LENGTH_MAX){
		length = size;
		times = 1;
		dma_dbg(MSG_DEBUG,"TX:file_length = %d, length = %d, times = %d\n", size, length, times);
		axi_dma_init(MM2S_CHANNEL, length, times-1, (unsigned long)m2s_dev->phybase,
				(unsigned long)(m2s_dev->regbase));
		if(ioctl(m2s_dev->fd, XDMA_START_WAIT_COMPLETE, &config_info) < 0)
		{
			perror("ioctl-wait");
		}
		axi_dma_reset(MM2S_CHANNEL, (unsigned long)(unsigned long)(m2s_dev->regbase), IP_RESET);
	} else {
		length = 4000;
		times = size/4000;
		sum = length * times;
		dma_dbg(MSG_DEBUG,"TX:file_length = %d, length = %d, times = %d\n", size, length, times);
		axi_dma_init(MM2S_CHANNEL, length, times-1, (unsigned long)m2s_dev->phybase,
				(unsigned long)(m2s_dev->regbase));

		if(ioctl(m2s_dev->fd, XDMA_START_WAIT_COMPLETE, &config_info) < 0)
		{
			perror("ioctl-wait");
		}
		axi_dma_reset(MM2S_CHANNEL, (unsigned long)(unsigned long)(m2s_dev->regbase), IP_RESET);
		if(size%4000 != 0) {
			length = size%4000;
			times = 1;
			dma_dbg(MSG_DEBUG,"TX:file_length = %d, length = %d, times = %d\n", size, length, times);
			axi_dma_init(MM2S_CHANNEL, length, times-1, (unsigned long)m2s_dev->phybase+sum,
					(unsigned long)(m2s_dev->regbase));

			if(ioctl(m2s_dev->fd, XDMA_START_WAIT_COMPLETE, &config_info) < 0)
			{
				perror("ioctl-wait");
			}
			axi_dma_reset(MM2S_CHANNEL, (unsigned long)(unsigned long)(m2s_dev->regbase), IP_RESET);
		}
		m2s_dev->mode = M_NORMAL;
	}

	return size;
}
#endif
