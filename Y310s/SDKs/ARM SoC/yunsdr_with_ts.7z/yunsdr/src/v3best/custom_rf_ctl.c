/*
 * custom_rf_ctl.c
 *
 *  Created on: 2015-1-19
 *      Author: v3
 */

#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <stdint.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>
#include "custom_rf_ctl.h"
#include "../ad9361-hw/ad9361.h"
#include "../ad9361-hw/platform_linux/platform.h"
#include "../ad9361-hw/console_commands/console.h"

#define FREQ_70MHZ    70000000UL
#define FREQ_2000MHZ  2000000000UL
#define FREQ_3000MHZ  3000000000UL
#define FREQ_3500MHZ  3500000000UL
#define FREQ_6000MHZ  6000000000UL

custom_command custom_cmd_list[] = {
		{"ref_select",   "reference clock select.", "", ref_select},
		{"vco_cal_select", "vco cal select.", "", vco_cal_select},
		{"fdd_tdd_select", "fdd or tdd select.", "", fdd_tdd_select},
		{"trx_sw", "tx & rx switch.", "", trx_sw},
		{"ad9361_auxdac1_set", "auxdac1 set.", "", ad9361_auxdac1_set},
		{"ad9361_adf4001_set", "adf4001 set.", "", ad9361_adf4001_set},

};

int custom_rf_ctl_init()
{
	int i;
	for(i = 54; i <= 62; i++){
		gpio_init(i);
		gpio_direction(i, 1);
	}

	return 0;
}
int gpio_rx1_band(uint8_t sel)
{
	if(sel == 1){
		gpio_set_value(RX1_BAND_SEL_A, 1);
		gpio_set_value(RX1_BAND_SEL_B, 0);
	}
	else if(sel == 2){
		gpio_set_value(RX1_BAND_SEL_A, 0);
		gpio_set_value(RX1_BAND_SEL_B, 1);
	}
	else if(sel == 3){
		gpio_set_value(RX1_BAND_SEL_A, 1);
		gpio_set_value(RX1_BAND_SEL_B, 1);
	}
	else
		return -1;

	return 0;
}
int gpio_rx2_band(uint8_t sel)
{
	if(sel == 1){
		gpio_set_value(RX2_BAND_SEL_A, 1);
		gpio_set_value(RX2_BAND_SEL_B, 0);
	}
	else if(sel == 2){
		gpio_set_value(RX2_BAND_SEL_A, 0);
		gpio_set_value(RX2_BAND_SEL_B, 1);
	}
	else if(sel == 3){
		gpio_set_value(RX2_BAND_SEL_A, 1);
		gpio_set_value(RX2_BAND_SEL_B, 1);
	}
	else
		return -1;

	return 0;
}
/* =10 3G~6G;=11 1.6~4G;=01 70~2.2G; followed by RX frequency adjustment. */
int rx1_band_sel(uint64_t freq)
{
	if(freq>=FREQ_70MHZ && freq<FREQ_2000MHZ){
		gpio_rx1_band(0x2);
	}
	else if(freq>=FREQ_2000MHZ && freq<FREQ_3500MHZ){
		gpio_rx1_band(0x3);
	}
	else if(freq>=FREQ_3500MHZ && freq<=FREQ_6000MHZ){
		gpio_rx1_band(0x1);
	}
	else
		return -1;

	return 0;
}
/* =11 3G~6G;=10 1.6~4G;=01 70~2.2G; followed by RX frequency adjustment. */
int rx2_band_sel(uint64_t freq)
{
	if(freq>=FREQ_70MHZ && freq<FREQ_2000MHZ){
		gpio_rx2_band(0x2);
	}
	else if(freq>=FREQ_2000MHZ && freq<FREQ_3500MHZ){
		gpio_rx2_band(0x1);
	}
	else if(freq>=FREQ_3500MHZ && freq<=FREQ_6000MHZ){
		gpio_rx2_band(0x3);
	}
	else
		return -1;

	return 0;
}
int gpio_tx_band(uint8_t sel)
{
	if(sel == 1){
		gpio_set_value(TX_BAND_SEL, 1);
	}
	else if(sel == 0){
		gpio_set_value(TX_BAND_SEL, 0);
	}
	else
		return -1;

	return 0;
}
int tx_band_sel(uint64_t freq)
{
	if(freq>=FREQ_70MHZ && freq<FREQ_3000MHZ){
		gpio_tx_band(0);
	}
	else if(freq>=FREQ_3000MHZ && freq<=FREQ_6000MHZ){
		gpio_tx_band(0x1);
	}
	else
		return -1;

	return 0;
}
int ref_select(uint32_t sel)
{
	if(sel == 1)
		gpio_set_value(REF_SELECT, 1);
	else if(sel == 0)
		gpio_set_value(REF_SELECT, 0);
	else
		return -1;

	return 0;
}
int vco_cal_select(uint32_t sel)
{
	if(sel == 1)
		gpio_set_value(VCO_CAL_SELECT, 1);
	else if(sel == 0)
		gpio_set_value(VCO_CAL_SELECT, 0);
	else
		return -1;

	return 0;
}
int fdd_tdd_select(uint32_t sel)
{
	if(sel == 1)
		gpio_set_value(FDD_TDD_SEL, 1);
	else if(sel == 0)
		gpio_set_value(FDD_TDD_SEL, 0);
	else
		return -1;

	return 0;
}
int trx_sw(uint32_t sel)
{
	if(sel == 1)
		gpio_set_value(TRX_SW, 1);
	else if(sel == 0)
		gpio_set_value(TRX_SW, 0);
	else
		return -1;

	return 0;
}

uint8_t custom_get_register(uint16_t reg_addr) // "register?" command
{
	//uint16_t reg_addr;
	uint8_t reg_val;

	//reg_addr = param[0];
	reg_val = ad9361_spi_read(NULL, reg_addr);
	console_print("register[0x%x]=0x%x\n", reg_addr, reg_val);

	return reg_val;
}
static int32_t ad9361_rf_rx_port_setup(uint32_t rx_inputs)
{
	uint32_t val;

	val = custom_get_register(REG_INPUT_SELECT);

	if (rx_inputs < 3){
		//val = 3 << (rx_inputs * 2);
		val = (val&(1<<6)) | (3 << (rx_inputs * 2));
	}

	return ad9361_spi_write(NULL, REG_INPUT_SELECT, val);
}
static int32_t ad9361_rf_tx_port_setup(uint32_t txb)
{
	uint32_t val;

	val = custom_get_register(REG_INPUT_SELECT);

	if (txb){
		//val |= TX_OUTPUT; /* Select TX1B, TX2B */
		val = (val&(~(1<<6))) | TX_OUTPUT;
	}
	else{
		//val |= TX_OUTPUT; /* Select TX1B, TX2B */
		val = (val&(~(1<<6)));
	}

	return ad9361_spi_write(NULL, REG_INPUT_SELECT, val);
}
int rx_rf_port_input_select(uint64_t freq)
{
	int32_t ret;

	if(freq>=FREQ_70MHZ && freq<FREQ_2000MHZ){
		ret = ad9361_rf_rx_port_setup(0x2);
		if (ret < 0)
			return ret;
	}
	else if(freq>=FREQ_2000MHZ && freq<FREQ_3500MHZ){
		ret = ad9361_rf_rx_port_setup(0x1);
		if (ret < 0)
			return ret;
	}
	else if(freq>=FREQ_3500MHZ && freq<=FREQ_6000MHZ){
		ret = ad9361_rf_rx_port_setup(0x0);
		if (ret < 0)
			return ret;
	}
	else
		return -1;

	return 0;
}
int tx_rf_port_input_select(uint64_t freq)
{
	int32_t ret;

	if(freq>=FREQ_70MHZ && freq<FREQ_3000MHZ){
		ret = ad9361_rf_tx_port_setup(0x1);
		if (ret < 0)
			return ret;
	}
	else if(freq>=FREQ_3000MHZ && freq<=FREQ_6000MHZ){
		ret = ad9361_rf_tx_port_setup(0x0);
		if (ret < 0)
			return ret;
	}
	else
		return -1;

	return 0;
}



/******************************************************************************/
/************************ Variables Definitions *******************************/
/******************************************************************************/

#define ADF4001_SPIDEV_DEV  "/dev/spidev1.0"
/***************************************************************************//**
 * @brief spi_init
 *******************************************************************************/
static int32_t adf4001_spi_init()
{
	uint8_t mode = SPI_MODE_0;
	uint8_t bits = 8;
	uint32_t speed = 1000000;
	int ret;
	int custom_spidev_fd;

	custom_spidev_fd = open(ADF4001_SPIDEV_DEV, O_RDWR);
	if (custom_spidev_fd < 0) {
		printf("%s: Can't open device\n\r", __func__);
		return -1;
	}

	ret = ioctl(custom_spidev_fd, SPI_IOC_WR_MODE, &mode);
	if (ret == -1) {
		printf("%s: Can't set spi mode\n\r", __func__);
		return ret;
	}

	ret = ioctl(custom_spidev_fd, SPI_IOC_WR_BITS_PER_WORD, &bits);
	if (ret == -1) {
		printf("%s: Can't set bits per word\n\r", __func__);
		return ret;
	}

	ret = ioctl(custom_spidev_fd, SPI_IOC_WR_MAX_SPEED_HZ, &speed);
	if (ret == -1) {
		printf("%s: Can't set max speed hz\n\r", __func__);
		return ret;
	}

	return custom_spidev_fd;
}
static int32_t adf4001_spi_deinit(int32_t spidev_fd)
{
	close(spidev_fd);
	return 0;
}

/***************************************************************************//**
 * @brief spi_write_then_read
 *******************************************************************************/
static int adf4001_spi_write(int32_t spidev_fd,
		const unsigned char *txbuf, unsigned n_tx)
{
	int ret;
	struct spi_ioc_transfer tr[1] = {
			{
					.tx_buf = (unsigned long)txbuf,
					.len = n_tx,
			},
	};

	ret = ioctl(spidev_fd, SPI_IOC_MESSAGE(1), &tr);
	if (ret == 1) {
		printf("%s: Can't send spi message\n\r", __func__);
		return -EIO;
	}

	return ret;
}
unsigned char txbuf[3][3] =
{{0x00,0x00,0x28},
		{0x00,0x1a,0x01},
		{0x0d,0x80,0xa2}};

int adf4001_prep_data(unsigned int rcount, unsigned int ncount)
{
	//int32_t ret;
	uint32_t val0 = 0, val1;

	val0 = rcount << 2;
	txbuf[0][0] = (val0&0x00FF0000)>>16;
	txbuf[0][1] = (val0&0x0000FF00)>>8;
	txbuf[0][2] = (val0&0x000000FF);

	val1 = (ncount << 8)|0x01;
	txbuf[1][0] = (val1&0x00FF0000)>>16;
	txbuf[1][1] = (val1&0x0000FF00)>>8;
	txbuf[1][2] = (val1&0x000000FF);

	return 0;
}

int adf4001_spi_setup()
{
	int32_t ret, i, j, spidev_fd;
	//	unsigned char txbuf[3][3] =
	//	{{0x00,0x00,0x28},
	//			{0x00,0x1a,0x01},
	//			{0x0d,0x80,0xa2}};
#if 0
	for(i = 0; i < 3; i++){
		spidev_fd = adf4001_spi_init();
		ret = adf4001_spi_write(spidev_fd, txbuf[i], sizeof(txbuf[i]));
		adf4001_spi_deinit(spidev_fd);
	}
#else
	spidev_fd = adf4001_spi_init();
	for(i = 0; i < 3; i++){
		ret = write(spidev_fd, txbuf[i], sizeof(txbuf[i]));
	}
	adf4001_spi_deinit(spidev_fd);
#if 0
	for(i = 0; i < 3; i++){
		for(j = 0; j < 3; j++)
			printf("buf[%d][%d] = 0x%x\t", i, j, txbuf[i][j]);
		printf("\n");
	}
#endif
#endif

	return ret ;
}

static int32_t custom_ad9361_spi_readm(struct spi_device *spi, uint32_t reg,
		uint8_t *rbuf, uint32_t num)
{
	uint8_t buf[2];
	int32_t ret;
	uint16_t cmd;

	if (num > MAX_MBYTE_SPI)
		return -EINVAL;

	cmd = AD_READ | AD_CNT(num) | AD_ADDR(reg);
	buf[0] = cmd >> 8;
	buf[1] = cmd & 0xFF;

	ret = spi_write_then_read(NULL, &buf[0], 2, rbuf, num);
	if (ret < 0) {
		printf("Read Error %d", ret);
		return ret;
	}

	return 0;
}

static int32_t custom_ad9361_spi_writef(uint32_t reg,
		uint32_t mask, uint32_t offset, uint32_t val)
{
	uint8_t buf;
	int32_t ret;

	if (!mask)
		return -EINVAL;

	ret = custom_ad9361_spi_readm(NULL, reg, &buf, 1);
	if (ret < 0)
		return ret;

	buf &= ~mask;
	buf |= ((val << offset) & mask);

	return ad9361_spi_write(NULL, reg, buf);
}

int32_t ad9361_auxdac1_set(uint32_t val_mV)
{
	uint32_t val, tmp;

	/* Disable DAC if val == 0, Ignored in ENSM Auto Mode */
	custom_ad9361_spi_writef(REG_AUXDAC_ENABLE_CTRL,
			AUXDAC_MANUAL_BAR(1), __ffs(AUXDAC_MANUAL_BAR(1)), val_mV ? 0 : 1);

	if (val_mV < 306)
		val_mV = 306;

	if (val_mV < 1888) {
		val = ((val_mV - 306) * 1000) / 1404; /* Vref = 1V, Step = 2 */
		tmp = AUXDAC_1_VREF(0);
	}
	else {
		val = ((val_mV - 1761) * 1000) / 1836; /* Vref = 2.5V, Step = 2 */
		tmp = AUXDAC_1_VREF(3);
	}

	val = clamp_t(uint32_t, val, 0, 1023);


	ad9361_spi_write(NULL, REG_AUXDAC_1_WORD, val >> 2);
	ad9361_spi_write(NULL, REG_AUXDAC_1_CONFIG, AUXDAC_1_WORD_LSB(val) | tmp);
	//phy->auxdac1_value = val_mV;

	return 0;
}
int32_t ad9361_adf4001_set(uint32_t param)
{
	adf4001_prep_data((param&0xFFFF0000)>>16,(param&0x0000FFFF));
	adf4001_spi_setup();

	return 0;
}
