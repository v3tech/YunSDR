/*
 * custom_rf_ctl.h
 *
 *  Created on: 2015-1-19
 *      Author: v3
 */
#ifndef __CUSTOM_RF_CTL_H__
#define __CUSTOM_RF_CTL_H__
/* GPIO define */
#define REF_SELECT         54
/* =1 external reference;=0 internal reference */

#define  VCO_CAL_SELECT    55
/* =1 AUXDAC1;=0 ADF4001 */

#define RX1_BAND_SEL_A     56
#define RX1_BAND_SEL_B     57
/* =10 3G~6G;=11 1.6~4G;=01 70~2.2G; followed by RX frequency adjustment. */

#define RX2_BAND_SEL_A     58
#define RX2_BAND_SEL_B     59
/* =11 3G~6G;=10 1.6~4G;=01 70~2.2G; followed by RX frequency adjustment. */

#define FDD_TDD_SEL        60
/* =1 FDD;=0 TDD */

#define TRX_SW             61
/* =1 TX;=0 RX */

#define TX_BAND_SEL        62
/* =1 3G~6G;=0 70~3G; followed by TX frequency adjustment. */

typedef int (*custom_cmd_function)(uint32_t param);
typedef struct
{
	const char* name;
	const char* description;
	const char* example;
	custom_cmd_function function;
}custom_command;

int custom_rf_ctl_init();

int gpio_rx1_band(uint8_t sel);
int gpio_rx2_band(uint8_t sel);
int gpio_tx_band(uint8_t sel);

int rx1_band_sel(uint64_t freq);
int rx2_band_sel(uint64_t freq);
int tx_band_sel(uint64_t freq);

int ref_select(uint32_t sel);
int vco_cal_select(uint32_t sel);
int fdd_tdd_select(uint32_t sel);
int trx_sw(uint32_t sel);

int rx_rf_port_input_select(uint64_t freq);
int tx_rf_port_input_select(uint64_t freq);
//static int32_t ad9361_rf_rx_port_setup(uint32_t rx_inputs);
//static int32_t ad9361_rf_tx_port_setup(uint32_t txb);

int32_t ad9361_auxdac1_set(uint32_t val_mV);

int adf4001_prep_data(uint32_t rcount, uint32_t ncount);
int adf4001_spi_setup();
int32_t ad9361_adf4001_set(uint32_t param);
#endif /* __CUSTOM_RF_CTL_H__ */
