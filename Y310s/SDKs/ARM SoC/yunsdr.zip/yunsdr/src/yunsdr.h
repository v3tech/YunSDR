/*
 * yunsdr.h
 *
 *  Created on: 2015-8-25
 *      Author: Eric
 */

#ifndef YUNSDR_H_
#define YUNSDR_H_
#include "v3best/yunsdr_hw.h"
#include "v3best/custom_rf_ctl.h"
#include "ad9361-hw/ad9361.h"
/*******************************RF API***********************************************/
/**
 * @brief Initialize the AD9361 part.
 * @param  device_type: device type,Y210,Y310,Y310S.
 * @return 0.
 */
int ad9361_main(uint32_t device_type);

/*******************************************************************************
 * @brief Gets current TX LO frequency [Hz].
 * @param param:Parameter array,param[0] is tx_lo_freq, output parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void get_tx_lo_freq(double* param, char param_no);


/*******************************************************************************
 * @brief Sets the TX LO frequency [MHz].
 * @param param:Parameter array,param[0] is tx_lo_freq, input parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void set_tx_lo_freq(double* param, char param_no);

/*******************************************************************************
 * @brief Gets current sampling frequency [Hz].
 * @param param:Parameter array,param[0] is tx_samp_freq, output parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void get_tx_samp_freq(double* param, char param_no);


/*******************************************************************************
 * @brief Sets the sampling frequency [Hz].
 * @param param:Parameter array,param[0] is tx_samp_freq, input parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void set_tx_samp_freq(double* param, char param_no);


/*******************************************************************************
 * @brief Gets current TX RF bandwidth [Hz].
 * @param param:Parameter array,param[0] is tx_rf_bandwidth, output parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void get_tx_rf_bandwidth(double* param, char param_no);


/*******************************************************************************
 * @brief Sets the TX RF bandwidth [Hz].
 * @param param:Parameter array,param[0] is tx_rf_bandwidth, input parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void set_tx_rf_bandwidth(double* param, char param_no);


/*******************************************************************************
 * @brief Gets current TX1 attenuation [mdB].
 * @param param:Parameter array,param[0] is tx1_attenuation, output parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void get_tx1_attenuation(double* param, char param_no);


/*******************************************************************************
 * @brief Sets the TX1 attenuation [mdB].
 * @param param:Parameter array,param[0] is tx1_attenuation, input parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void set_tx1_attenuation(double* param, char param_no);


/*******************************************************************************
 * @brief Gets current TX2 attenuation [mdB].
 * @param param:Parameter array,param[0] is tx2_attenuation, output parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void get_tx2_attenuation(double* param, char param_no);


/*******************************************************************************
 * @brief Sets the TX2 attenuation [mdB].
 * @param param:Parameter array,param[0] is tx2_attenuation, input parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void set_tx2_attenuation(double* param, char param_no);


/*******************************************************************************
 * @brief Gets current TX FIR state.
 * @param param:Parameter array,param[0] is tx_fir_en, output parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void get_tx_fir_en(double* param, char param_no);


/*******************************************************************************
 * @brief Sets the TX FIR state.
 * @param param:Parameter array,param[0] is tx_fir_en, input parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void set_tx_fir_en(double* param, char param_no);


/*******************************************************************************
 * @brief Gets current RX LO frequency [Hz].
 * @param param:Parameter array,param[0] is rx_lo_freq, output parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void get_rx_lo_freq(double* param, char param_no);


/*******************************************************************************
 * @brief Sets the RX LO frequency [Hz].
 * @param param:Parameter array,param[0] is rx_lo_freq, input parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void set_rx_lo_freq(double* param, char param_no);


/*******************************************************************************
 * @brief Gets current RX sampling frequency [Hz].
 * @param param:Parameter array,param[0] is rx_samp_freq, output parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void get_rx_samp_freq(double* param, char param_no);


/*******************************************************************************
 * @brief Sets the RX sampling frequency [Hz].
 * @param param:Parameter array,param[0] is rx_samp_freq, input parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void set_rx_samp_freq(double* param, char param_no);


/*******************************************************************************
 * @brief Gets current RX RF bandwidth [Hz].
 * @param param:Parameter array,param[0] is rx_rf_bandwidt, output parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void get_rx_rf_bandwidth(double* param, char param_no);


/*******************************************************************************
 * @brief Sets the RX RF bandwidth [Hz].
 * @param param:Parameter array,param[0] is rx_rf_bandwidt, input parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void set_rx_rf_bandwidth(double* param, char param_no);


/*******************************************************************************
 * @brief Gets current RX1 GC mode.
 * @param param:Parameter array,param[0] is rx1_gc_mode, output parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void get_rx1_gc_mode(double* param, char param_no);


/*******************************************************************************
 * @brief Sets the RX1 GC mode.
 * @param param:Parameter array,param[0] is rx1_gc_mode, input parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void set_rx1_gc_mode(double* param, char param_no);


/*******************************************************************************
 * @brief Gets current RX2 GC mode.
 * @param param:Parameter array,param[0] is rx2_gc_mode, output parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void get_rx2_gc_mode(double* param, char param_no);


/*******************************************************************************
 * @brief Sets the RX2 GC mode.
 * @param param:Parameter array,param[0] is rx2_gc_mode, input parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void set_rx2_gc_mode(double* param, char param_no);


/*******************************************************************************
 * @brief Gets current RX1 RF gain.
 * @param param:Parameter array,param[0] is rx1_rf_gain, output parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void get_rx1_rf_gain(double* param, char param_no);

/*******************************************************************************
 * @brief Sets the RX1 RF gain.
 * @param param:Parameter array,param[0] is rx1_rf_gain, input parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void set_rx1_rf_gain(double* param, char param_no);

/*******************************************************************************
 * @brief Gets current RX2 RF gain.
 * @param param:Parameter array,param[0] is rx2_rf_gain, output parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void get_rx2_rf_gain(double* param, char param_no);

/*******************************************************************************
 * @brief Sets the RX2 RF gain.
 * @param param:Parameter array,param[0] is rx2_rf_gain, input parameter;
 * 	      param_no: number of param[], the default value of 1.
 * @return None.
*******************************************************************************/
void set_rx2_rf_gain(double* param, char param_no);


/******************************************************************************/

/*******************************************************************************
 * @brief Sets the reference clock.
 * @param sel		=1 external reference;=0 internal reference;
 * @return 			0:Normal return; -1:error.
*******************************************************************************/
int ref_select(uint32_t sel);

/*******************************************************************************
 * @brief Sets the VCO calibrate clock.
 * @param sel 		=1 AUXDAC1;=0 ADF4001;
 * @return 			0:Normal return; -1:error.
*******************************************************************************/
int vco_cal_select(uint32_t sel);

/*******************************************************************************
 * @brief Sets the dulex mode.
 * @param sel		=1 FDD;=0 TDD;
 * @return 			0:Normal return; -1:error.
*******************************************************************************/
int fdd_tdd_select(uint32_t sel);

/*******************************************************************************
 * @brief trx port switch.
 * @param sel		=1 TX;=0 RX;
 * @return 			0:Normal return; -1:error.
*******************************************************************************/
int trx_sw(uint32_t sel);

/*******************************************************************************
 * @brief Sets the AUXDAC for VCO when the parameter of vco_cal_select function is 1.
 * @param val_mV	Parameter will be set[0~2000mV];
 * @return 			0:Normal return; -1:error.
*******************************************************************************/
int ad9361_auxdac1_set(uint32_t val_mV);

/*******************************************************************************
 * @brief Sets the ADF4001 for VCO when the parameter of vco_cal_select function is 0.
 * @param param		Parameter will be set(ncount[31:16]|rcount[15:0]);
 * @return 			0:Normal return; -1:error.
*******************************************************************************/
int ad9361_adf4001_set(uint32_t param);


/******************************************dma hw API *************************/
/**
 * @brief  The struct describe adc&dac channel.
 *
 */
struct dma_dev {
	int fd;
	uint8_t *regbase;
	uint8_t *membase;
	uint32_t phybase;
	uint8_t mode;
	uint8_t dir;
};

/**
 * @brief  map hw control reg.
 *
 * @param                      None
 * @retval                     The regbase Virtual DDR address
 *
 */
uint8_t *init_hw_control(void);

/**
 * @brief  reset dac dma channel when it works on loopback mode.
 *
 * @param[in] dev              The struct describe adc&dac channel
 * @retval                     0:Normal return; -1:error
 *
 */
int hw_reset(struct dma_dev *dev);

/**
 * @brief  init dac dma channel, map regbase and membase.
 *
 * @param[out] s2m_dev         The struct describe dac channel
 * @retval                     0:Normal return; -1:error
 *
 */
int init_s2m_channel(struct dma_dev *s2m_dev);

/**
 * @brief  init adc dma channel, map regbase and membase.
 *
 * @param[out] m2s_dev         The struct describe adc channel
 * @retval                     0:Normal return; -1:error
 *
 */
int init_m2s_channel(struct dma_dev *m2s_dev);

/**
 * @brief  release adc dma channel, unmap regbase and membase.
 *
 * @param[out] s2m_dev         The struct describe adc channel
 * @retval                     0:Normal return; -1:error
 *
 */
int deinit_s2m_channel(struct dma_dev *s2m_dev);

/**
 * @brief  release dac dma channel, unmap regbase and membase.
 *
 * @param[out] m2s_dev         The struct describe dac channel
 * @retval                     0:Normal return; -1:error
 *
 */
int deinit_m2s_channel(struct dma_dev *m2s_dev);

/**
 * @brief  read up to size bytes via adc dma channel into the buffer starting at buf.
 *
 * @param[in]  s2m_dev     	    The struct describe adc channel
 * @param[out] buf              cache the samples
 * @param[in]  size             size samples to be read
 * @param[in]  mode             not used
 * @retval                      On success,The number of bytes read; On error, -1 is returned
 *
 */
int read_samples(struct dma_dev *s2m_dev, uint8_t *buf, uint32_t size, uint8_t mode);

/**
 * @brief  write up to size bytes from the buffer pointed buf via dac dma channel.
 *
 * @param[in]  m2s_dev     	    The struct describe dac channel
 * @param[out] buf              cache the samples
 * @param[in]  size             size samples to be written
 * @param[in]  mode             dma mode(normal;loopback)
 * @retval                      On success,The number of bytes written; On error, -1 is returned
 *
 */
int write_samples(struct dma_dev *m2s_dev, uint8_t *buf, uint32_t size, uint8_t mode);



#endif /* YUNSDR_H_ */
